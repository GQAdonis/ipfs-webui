# Retain and assess node-backed decision axe incomplete results

During #11, the existing node-backed decision and shell registrations were found to discard axe's `incomplete` list. The shell correction now retains full reports before the unchanged assertion. Its current sixteen theme/width reports contain zero violations and zero incomplete occurrences, on artifact `b9c25a7631a0d37d1353efd8f38be7a059f9f63c22f269a3112c1c7e3cc5d69c`.

The decision registration still retains pass IDs and detected violations only (`test/boundary/accessibility/contributions/decisions.mjs`). Its incomplete inventory is **not verified**, not zero. This remaining reporting/assessment gap is separate from the original sixteen static reports and 384 retained occurrences assessed for #11.

## Acceptance criteria

- Preserve all five families/four slots, production hosts, current source/runtime/PNG checks, thresholds, assertions and negative controls.
- Retain full incomplete rule/check and node data for every decision surface/phase/theme/viewport, including unsuccessful or partial outcomes. Add regression coverage proving those results survive evidence serialization. Preserve the shell's new complete retention.
- Assess newly retained occurrences against the exact current DOM using computed foreground/composited backgrounds, opacity/filter/blend ancestry, visibility, scrolling/clipping, point hits and bound screenshots. Unsupported paint or missing identity remains unresolved.
- Refresh affected artifacts and real WU/SU evidence through normal producers. Require separate product/security review and exact owned cleanup. Do not weaken the zero-violation assertion or infer contrast completion from source tokens.

This issue supplies no whole-WCAG, physical assistive-technology, native-presence, backend lease or effect/model-interruption certification. Presentation fixtures remain distinct from those owner obligations.

## References

- https://github.com/GQAdonis/ipfs-webui/issues/11
- https://github.com/GQAdonis/ipfs-webui/issues/10
- https://github.com/tribe-health/ipfs-desktop/issues/6
