import hashlib
import json
import os
from pathlib import Path

base = Path('/Users/gqadonis/.codex/worktrees/agentic-ui-frontend')
evidence = base / 'kubo/evidence/agentic-ui-frontend/issue11-clearance'
origin = base / 'ipfs-desktop/node_modules/electron/dist'
copy = evidence / 'su-source-snapshot-v2/ipfs-desktop/node_modules/electron/dist'

def inventory(root):
    result = {}
    for directory, directories, files in os.walk(root, followlinks=False):
        for name in sorted(directories + files):
            path = Path(directory) / name
            relative = str(path.relative_to(root))
            if path.is_symlink():
                result[relative] = {'kind': 'link', 'target': os.readlink(path)}
            elif path.is_file():
                result[relative] = {'kind': 'file', 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'mode': path.stat().st_mode & 0o777}
    return result

source_before = inventory(origin)
copy_before = inventory(copy)
assert set(source_before) == set(copy_before)
changes = []
for relative, fact in source_before.items():
    current = copy_before[relative]
    if fact['kind'] == 'file':
        assert fact == current, ('Regular dependency file drift', relative)
    elif fact != current:
        assert current['kind'] == 'link'
        assert not os.path.isabs(fact['target'])
        expected = os.path.normpath(str(origin / Path(relative).parent / fact['target']))
        assert current['target'] == expected, ('Unexpected dependency link', relative)
        changes.append({'path': relative, 'before': current['target'], 'after': fact['target']})
assert len(changes) == 14, ('Unexpected correction count', len(changes))
with (evidence / 'su-electron-copy-before-repair.json').open('x') as out:
    json.dump({'origin': str(origin), 'copy': str(copy), 'source': source_before, 'copied': copy_before, 'plannedChanges': changes}, out, indent=2)
    out.write('\n')
for change in changes:
    target = copy / change['path']
    assert target.is_symlink() and os.readlink(target) == change['before']
    target.unlink()
    os.symlink(change['after'], target)
source_after = inventory(origin)
copy_after = inventory(copy)
assert source_after == source_before
assert copy_after == source_after
with (evidence / 'su-electron-copy-repair.json').open('x') as out:
    json.dump({'kind': 'ignored-Electron-dependency-copy-layout-repair', 'origin': str(origin), 'copy': str(copy), 'changes': changes, 'sourceUnchanged': True, 'regularFilesUnchanged': True, 'completeCopiedBundleMatchesSource': True, 'after': copy_after, 'reason': 'fs.cp default resolved relative framework links. Restore original relative link text, equivalent to verbatimSymlinks:true. No application source, artifact, runtime argument, validator or binary bytes changed.', 'documentation': 'https://github.com/nodejs/node/blob/v26.0.0/doc/api/fs.md'}, out, indent=2)
    out.write('\n')
print(json.dumps({'changedLinks': len(changes), 'completeBundleEntries': len(copy_after), 'status': 'PASS'}))
