import assert from 'node:assert/strict'
import { createReadStream } from 'node:fs'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
const root = '/Users/gqadonis/.codex/worktrees/agentic-ui-frontend/ipfs-webui-issue10-publication'
const kubo = resolve(root, '../kubo')
assert.match(process.argv[3] || '', /^[a-f0-9]{64}$/, 'Explicit expected current export SHA256 is required')
const out = resolve(process.argv[2])
assert(out.startsWith(join(kubo, 'evidence/agentic-ui-frontend/issue11-clearance/shell-axe-diagnostic/') ))
await mkdir(out, { recursive: false })
const load = path => import(pathToFileURL(join(root, path)).href)
const { startOwnedKubo } = await load('test/helpers/owned-kubo.mjs')
const { Processes } = await load('test/boundary/processes.mjs')
const { assertLocalWebuiExport, treeFiles, sha256 } = await load('scripts/local-artifact.mjs')
const { injectAxe } = await load('test/boundary/accessibility/decisions/browser.mjs')
const { inspectElement } = await load('test/boundary/accessibility/contrast/inspect.mjs')
const { chromium, expect } = await load('node_modules/@playwright/test/index.mjs')
const scratch = join(out, 'scratch'); await mkdir(scratch)
const processes = new Processes(join(out, 'commands'))
const receipt = join(kubo, 'evidence/agentic-ui-frontend/issue11-clearance/node-delivery-v2/artifact-binding-receipt.json')
const bind = async path => ({ path, sha256: sha256(await readFile(path)) })
const summary = { kind: 'production-shell-axe-diagnostic', acceptanceAuthority: false, state: 'same shared-path production shell as UI112', originalSourceUnchanged: true, reports: [], bindings: [], cleanup: [] }
const record = async (name, value) => { const path = join(out, name + '.json'); await writeFile(path, JSON.stringify(value, null, 2) + '\n', { flag: 'wx' }); const binding = await bind(path); summary.bindings.push(binding); return binding }
let node, browser
try {
  const artifact = await assertLocalWebuiExport({ root, kubo })
  summary.export = { artifactSha256: artifact.artifactSha256, manifest: await bind(join(root, 'build/WEBUI_ARTIFACT.json')) }
  assert.equal(artifact.artifactSha256, process.argv[3])
  summary.sources = await Promise.all(['test/boundary/chat-runtime/shell-accessibility.mjs', 'test/helpers/owned-kubo.mjs', 'test/boundary/accessibility/decisions/browser.mjs', 'src/shell/praxis.css', 'src/shell/workspace.css'].map(path => bind(join(root, path))))
  summary.adapter = await bind(new URL(import.meta.url).pathname)
  summary.makeBuildReceipt = await bind(receipt)
  node = await startOwnedKubo({ kubo, scratch, processes, label: 'shell-diagnostic', makeBuildReceipt: receipt })
  summary.node = { binary: node.identity, repo: node.repo, ports: node.ports, peerId: node.id.id, configSha256: sha256(await readFile(join(node.repo, 'config'))) }
  const files = await treeFiles(join(root, 'build'))
  async function * source () { for (const path of Object.keys(files)) yield { path: `webui/${path}`, content: createReadStream(join(root, 'build', path)) } }
  const recipe = { cidVersion: 1, rawLeaves: true, hashAlg: 'sha2-256', wrapWithDirectory: true, pin: true }
  let imported
  for await (const result of node.api.addAll(source(), recipe)) if (result.path === '') imported = result.cid.toString()
  assert(imported)
  const baseURL = `${node.gatewayUrl}/ipfs/${imported}/webui/`
  summary.productionHost = { baseURL, imported, recipe, files: Object.keys(files).length }
  summary.browser = { executable: chromium.executablePath(), executableSha256: sha256(await readFile(chromium.executablePath())) }
  browser = await chromium.launch({ headless: true }); summary.browser.version = browser.version()
  for (const width of [540, 539]) {
    const theme = 'dark'
    const context = await browser.newContext({ viewport: { width, height: 1000 }, colorScheme: theme, acceptDownloads: true, locale: 'en-US' })
    try {
      await context.addInitScript(({ apiUrl, gatewayUrl, theme }) => {
        if (!localStorage.getItem('ipfsApi')) localStorage.setItem('ipfsApi', JSON.stringify(apiUrl))
        const gateway = new URL(gatewayUrl)
        localStorage.setItem('kuboGateway', JSON.stringify({ host: gateway.hostname, port: Number(gateway.port), protocol: 'http', trustlessBlockBrokerConfig: { init: { allowInsecure: true, allowLocal: true } } }))
        localStorage.setItem('explore.ipld.gatewayEnabled', 'false'); localStorage.setItem('files.viewMode', JSON.stringify('list'))
        if (!localStorage.getItem('i18nextLng')) localStorage.setItem('i18nextLng', 'en')
        if (!localStorage.getItem('ipfs-webui:theme:v1')) localStorage.setItem('ipfs-webui:theme:v1', theme)
      }, { apiUrl: node.apiUrl, gatewayUrl: node.gatewayUrl, theme })
      const allowed = new Set([baseURL, node.apiUrl, node.gatewayUrl].map(url => new URL(url).origin))
      const blockedRequests = []
      await context.route('**/*', route => {
        const url = new URL(route.request().url())
        if (['http:', 'https:'].includes(url.protocol) && !allowed.has(url.origin)) { blockedRequests.push({ origin: url.origin }); return route.abort('blockedbyclient') }
        return route.continue()
      })
      const page = await context.newPage(); page.setDefaultTimeout(15000)
      await page.goto(`${baseURL}#/`); await expect(page.locator('main').first()).toBeVisible()
      if (width < 540) {
        const nav = page.getByRole('navigation', { name: 'Primary navigation', exact: true })
        await expect(nav).toBeVisible()
        assert.deepEqual((await nav.locator('a,button').allTextContents()).map(x => x.trim()), ['Home', 'Files', 'Pins', 'Activity', 'More'])
        await nav.getByRole('button', { name: 'More', exact: true }).click()
        const dialog = page.getByRole('dialog', { name: 'More destinations' }); await expect(dialog).toBeVisible()
        for (const name of ['Explore', 'Peers', 'Status', 'Diagnostics', 'Settings']) await expect(dialog.getByRole('link', { name, exact: true })).toBeVisible()
      }
      await injectAxe({ kubo, record: (name, value) => record(`${theme}-${width}-${name}`, value) }, page)
      const report = await page.evaluate(async () => window.axe.run(document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa', 'best-practice'] } }))
      const fullReport = await record(`${theme}-${width}-axe`, report)
      const screenshot = join(out, `${theme}-${width}.png`); await page.screenshot({ path: screenshot, fullPage: false })
      const observations = []
      for (const rule of [...report.violations, ...report.incomplete]) for (const target of rule.nodes) {
        const observation = { rule: rule.id, target: target.target, html: target.html }
        if (target.target.length === 1 && typeof target.target[0] === 'string') {
          try { const locator = page.locator(target.target[0]); if (await locator.count() === 1) observation.computed = await locator.evaluate(inspectElement) } catch (error) { observation.error = error.message }
        }
        observations.push(observation)
      }
      const rendered = await record(`${theme}-${width}-rendered`, { theme, width, observations, blockedRequests, actualTheme: await page.locator('html').getAttribute('data-theme') })
      summary.reports.push({ theme, width, fullReport, screenshot: await bind(screenshot), rendered, violations: report.violations.map(x => ({ id: x.id, nodes: x.nodes.length })), incomplete: report.incomplete.map(x => ({ id: x.id, nodes: x.nodes.length })) })
      console.log(JSON.stringify(summary.reports.at(-1)))
      // Preserve complete evidence before asserting the exact observed red case.
      assert.equal(report.violations.length, 0, 'Actual production shell must have zero axe violations')
      assert.equal(report.incomplete.filter(rule => rule.id === 'aria-prohibited-attr').length, 0, 'Named suggestions must not retain the known ARIA incomplete')
      if (width === 540) {
        const contrast = report.passes.find(rule => rule.id === 'color-contrast')
        const targets = contrast?.nodes.filter(node => node.html.includes('aria-label="Remove reference /"')) ?? []
        assert.equal(targets.length, 1, 'Exact page reference Remove button must have a passing contrast measurement')
        const check = targets[0].any.find(check => check.id === 'color-contrast')
        assert(check?.data?.contrastRatio >= 4.5, 'Active Remove text contrast must meet 4.5:1 without exemption')
        summary.removeButton = { target: targets[0].target, html: targets[0].html, check, report: fullReport }
      }
    } finally { await context.close() }
  }
  assert.equal((await assertLocalWebuiExport({ root, kubo })).artifactSha256, artifact.artifactSha256)
} catch (error) { summary.error = { name: error.name, message: error.message, stack: error.stack }; process.exitCode = 1 } finally {
  if (browser) try { await browser.close() } catch (error) { summary.cleanup.push(error.message) }
  if (node) try { await node.stop() } catch (error) { summary.cleanup.push(error.message) }
  try { await processes.stop() } catch (error) { summary.cleanup.push(error.message) }
  await writeFile(join(out, 'summary.json'), JSON.stringify(summary, null, 2) + '\n', { flag: 'wx' })
  console.log(JSON.stringify({ error: summary.error, cleanup: summary.cleanup, reports: summary.reports.length }))
}
