# Production shell correction confirmation

The normal production export **b9c25a7631a0d37d1353efd8f38be7a059f9f63c22f269a3112c1c7e3cc5d69c** passes the exact previously failing dark540 state: zero axe violations and zero incompletes. The active Remove reference button is measured at **5:1** (`#e96a12` on `#222120`), above the unchanged 4.5:1 requirement. The original d33 export measured 4.34:1 on control fill. The neighboring dark539 More-sheet control also has zero violations/incompletes.

Only the approved consumer fill changed from control to raised; palette and shared button semantics remain. The existing suggestions label now has the appropriate group role. The existing shell contributor retains full axe results and screenshots before its unchanged assertion. Home and PraxisWorkspace tests passed15/15; the new Home test checks accessible grouping and preserves all three draft actions without submitting.

The confirmation reused the original owned make-built node helper, explicit v2 receipt, current export verification, exact production gateway import recipe, browser state and pinned axe tags. It asserts zero violations, no known ARIA incomplete, one exact active Remove-reference/ contrast result and ratio>=4.5. Complete reports were written before assertions. It completed exit0 with cleanup[]. The actual dark540 PNG was opened visually; a live guided-tour tooltip appears in this capture and is retained rather than suppressed. No fixture style or oracle was weakened.

Original diagnostic runtime-1 and its complete red report remain unchanged. This two-state diagnostic confirms the causal correction; full WU/SU and independent review are separate gates. It does not certify full WCAG or physical assistive technology.
