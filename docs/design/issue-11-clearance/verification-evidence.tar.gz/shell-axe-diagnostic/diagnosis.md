# Actual production shell: dark 540px failure

The unchanged current production export reproduces the shell failure: **one serious color-contrast violation**, the `Remove` reference button inside `.praxis-home > .praxis-chat-host` → shadow `.iu-btn--text`. The complete pinned axe report measures foreground `#e96a12` against composer background `#2d2c2a`, ratio **4.34:1**, at 14.5px normal text (required 4.5:1). `runtime-1/dark-540.png` was opened visually and shows the actual production shell and reference button.

The source cause is the WebUI host override in `src/agent-chat/ComposedChat.jsx:13`: `.praxis-composer` is given `background:var(--control)`. The shared text button correctly uses `--accent-text`. Kubo `DESIGN.md:32` and `:81` explicitly exclude accent-text on control in dark mode. This is an invalid consumer pairing, not a palette defect. Nested composer surface `--raised` would preserve the existing palette and intended text-button contrast, while leaving actual fields and secondary buttons on `--control`. The architect must route that narrow production edit before implementation.

The same full report retains one separate `aria-prohibited-attr` incomplete: `src/shell/Home.jsx:8` names `.praxis-suggestions` with `aria-label="Draft suggestions"` on a div without a role. Adding the appropriate group role would express the existing named group. This incomplete is retained and is not waived.

The neighboring dark539 state follows the original phone interaction, opens the More destinations dialog and reports zero violations and zero incompletes. This is a boundary control, not evidence that the underlying page's covered controls pass.

The diagnostic uses the existing owned-node helper and explicit `node-delivery-v2/artifact-binding-receipt.json`, exact current artifact `d33f8a78ff496756ff0c28a8dfff75e8e7543641739e7dd39558356e0fb74733`, original addAll recipe and actual local Kubo gateway shared path. It uses the original browser storage, themes, dimensions, allowlisted egress and pinned axe configuration. It creates no operator-node connection, alternate static host, remote asset source, mock response or agent credential. No shared source or original oracle changed. Complete axe passes/violations/incompletes and PNGs are retained before reporting outcomes. Exit0 means diagnostic completed, not acceptance PASS; cleanup recorded no errors.

| Artifact | SHA256 |
| --- | --- |
| `runtime-1/dark-540-axe.json` | `9876d9832a23c341d9becac3a3a7d9be6af896fe03fbbb67812d256e746215cf` |
| `runtime-1/dark-540.png` | `38761890e98e781449cf07467a052b525cba7e9416adfebcf1359d08c9383d5d` |
| `runtime-1/dark-539-axe.json` | `2412178a86baf4fab2f61a636c8130123371d65e54d1cbb3f8fd8d38f4f294a0` |
| `runtime-1/dark-539.png` | `ca7b31724a9adf399a5ea273df144fc3f6976af1399cd97c445f557bbf42b72a` |

This finding does not alter the separate original16/384 supplemental contrast assessment, which has a different exact scope. The production shell's invalid pairing remains a blocker until corrected and validated against a fresh normal export.
