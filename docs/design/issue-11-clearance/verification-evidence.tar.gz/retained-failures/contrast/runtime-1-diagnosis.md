# First runtime disposition and observer correction

The immutable first run measured all 384 retained occurrences: **376 PASS, 0 FAIL, 8 UNKNOWN**. All 268 pseudo-element cases and 108 virtual event cases earned computed contrast results after native scrolling, unique target rebinding, captured paint stability and unobscured point hits. The minimum observed ratio is 4.908531945906348, above the applicable 4.5 threshold. No new axe invocation occurred; cleanup recorded no errors.

The eight unknown occurrences are the same host fixture H1 in inbox/activity, light/dark, 375/1440px states. Their ratios are 16.74569264768206 (light) and 17.621719237053668 (dark), with threshold 3. Runtime-1 does not clear these: the first text line was classified clipped and therefore was not hit-tested.

The observer incorrectly intersected its text geometry with the BODY box top (21.4375px), rejecting the first text range top (18.4375px). [CSS Overflow 3 section 3.3](https://www.w3.org/TR/css-overflow-3/#overflow-propagation) requires applicable BODY overflow to propagate to the viewport when HTML overflow is visible on both axes; the source element then uses visible overflow. Containment disables the BODY special case. The retained phone-light screenshot shows the whole heading visibly present.

The minimal observer correction records containment and the propagation source, then preserves viewport clipping instead of applying the source element box. Four focused tests pass, including a browser regression that proves real clipping and overlays still remain unknown. No fixture, production style, ratio threshold or acceptance oracle changed. A fresh retained runtime is required to obtain the missing first-line point hits and determine the eight dispositions. The first run remains unchanged.

Manual visual spot checks opened the light-phone H1, dark-desktop minimum-ratio table header, and a scrolled light-phone virtual event10 occurrence. These support the recorded geometry and colors but are not independent review or full WCAG certification. The JSON companion binds the first summary and each unresolved occurrence screenshot.
