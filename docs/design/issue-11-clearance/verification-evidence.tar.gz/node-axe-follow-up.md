# Retain and assess node-backed axe incomplete results

The remaining-evidence work in #11 measures the original sixteen static reports and all 384 retained incomplete occurrences. The existing node-backed decision and production-shell axe registrations retain detected violations and pass IDs, but discard axe's `incomplete` list. Their incomplete inventory is therefore **not verified**, not zero. This is newly identified coverage beyond those original 384 occurrences.

## Scope

- Preserve the existing five-family/four-slot orchestration, production hosts, source/runtime/PNG checks, thresholds, assertions and negative controls.
- Retain current node-backed decision and shell axe incompletes, including rule/check data and exact node identity, theme, viewport and surface/phase. Keep unsuccessful and partial outcomes truthful.
- Assess every newly retained occurrence against the exact current DOM using computed foreground/composited backgrounds, opacity/filter/blend ancestry, visibility, scroll/clipping, point hits and bound screenshots. Reuse the conservative observer where appropriate; unsupported paint remains unresolved.
- Refresh affected source-bound artifacts and real WU/SU evidence through normal producers. Require separate product/security review and exact owned cleanup.
- Add regression coverage demonstrating that incomplete results survive evidence serialization. Do not weaken the current zero-violation assertion or infer completeness from source palette arithmetic.

This issue supplies no whole-WCAG, physical assistive-technology, native-presence, backend lease or effect/model-interruption certification. Presentation fixtures remain distinct from those owner obligations.

## References

- https://github.com/GQAdonis/ipfs-webui/issues/11
- https://github.com/GQAdonis/ipfs-webui/issues/10
- https://github.com/tribe-health/ipfs-desktop/issues/6
