# Fresh issue 11 build delivery, version 2

This delivery is a genuine new same-checkout `/usr/bin/make build`, produced by the native `mcp_server_engineer` role under Codex. It replaces v1 for current build provenance because v1 did not capture every non-Go embedded input before its build. V1 remains historical and unchanged.

`build.mjs` records a fresh complete before snapshot, canonical build command and logs (PID 70900, exit 0), and after snapshot. The capture covers all Go/module/lock source inputs, Makefiles, full `assets/`, full `mcp/contract/`, `mcp/app/dist/`, `mcp/ui/catalog/`, and `mcp/server/confirm/la_prompt.swift`. `go-embed-declarations.json` inventories the five actual non-test Go embed owners from the Go source inventory. All before/after source and embedded-input bytes match. Go, Make, gmake and gofmt executable hashes also match before/after.

The process environment is explicitly allowlisted, with an isolated `HOME`, unused `IPFS_PATH`, `GOFLAGS=-mod=readonly`, `GOENV=off`, local toolchain, offline module selection and disabled telemetry. No inherited operator credential variables, daemon initialization, lease helper, install, binary substitution or source repair is involved.

`build-receipt.json` retains the generic BLOCKED identity verdict because canonical `-trimpath` causes Go to omit linker settings in buildinfo. It does not overwrite that causal failure. `identity-diagnostic.json` independently records the actual binary version and bytes. `artifact-binding-receipt.json` links those immutable originals and provides a separately verified current source/artifact attestation for the strict frontend validator. `bind.mjs` runs no build or daemon; it verifies snapshots, retained successful command logs, the three Makefile injections, current binary/buildinfo/version and tool identities.

Current binary: `cmd/ipfs/ipfs`, SHA-256 `792cb3b214b54daafd8ae432113a8a22c5cf6e0df7c4a15c38de60b28f52eccf`.

Current complete embedded/Makefile inputs digest: `27220580dac3068046397614f2a5b534499ef7431acbc1a81cffa74cfa071223`.

This evidence establishes local build provenance only. It is not a backend compatibility result, BE04 authorization, lease adoption, live backend certification or prior Claude producer receipt. The binary's unchanged hash does not substitute for the new before/build/after evidence.
