import { spawn } from 'node:child_process'
import { mkdir, readFile, writeFile, realpath, lstat } from 'node:fs/promises'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { kuboInputs } from '../../../../../ipfs-webui/test/boundary/evidence-schema.mjs'
import { sha256, snapshot } from '../../../../../ipfs-webui/scripts/local-artifact.mjs'

const directory = dirname(fileURLToPath(import.meta.url))
const kubo = resolve(directory, '../../../..')
const scratch = join(directory, 'isolated-home')
await mkdir(scratch, { recursive: true })
const env = {
  PATH: '/opt/homebrew/opt/go/libexec/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin',
  HOME: scratch, TMPDIR: '/tmp', LANG: 'C', LC_ALL: 'C',
  GOPATH: '/Users/gqadonis/go', GOMODCACHE: '/Users/gqadonis/go/pkg/mod',
  GOCACHE: '/Users/gqadonis/Library/Caches/go-build',
  GOENV: 'off', GOTOOLCHAIN: 'local', GOFLAGS: '-mod=readonly', GOPROXY: 'off', GOSUMDB: 'off',
  IPFS_PATH: join(scratch, 'unused-ipfs-repo'), IPFS_TELEMETRY: 'off', DO_NOT_TRACK: '1'
}
const commands = []
async function run(command, args, { input, label = command.split('/').at(-1), timeout = 20 * 60 * 1000 } = {}) {
  const prefix = `${String(commands.length + 1).padStart(3, '0')}-${label}`
  const receipt = { argv: [command, ...args], cwd: kubo, environment: env, startedAt: new Date().toISOString(), stdoutFile: `${prefix}.stdout.txt`, stderrFile: `${prefix}.stderr.txt` }
  commands.push(receipt)
  const child = spawn(command, args, { cwd: kubo, env, stdio: ['pipe', 'pipe', 'pipe'] })
  receipt.pid = child.pid
  child.stdin.end(input)
  const stdout = [], stderr = []
  child.stdout.on('data', bytes => stdout.push(bytes))
  child.stderr.on('data', bytes => stderr.push(bytes))
  const timer = setTimeout(() => { receipt.timedOut = true; child.kill('SIGTERM') }, timeout)
  const forceTimer = setTimeout(() => { if (receipt.timedOut && child.exitCode === null) child.kill('SIGKILL') }, timeout + 5000)
  const result = await new Promise((res, rej) => { child.once('error', rej); child.once('close', (exitCode, signal) => res({ exitCode, signal })) })
  clearTimeout(timer); clearTimeout(forceTimer)
  Object.assign(receipt, result, { endedAt: new Date().toISOString() })
  const out = Buffer.concat(stdout), err = Buffer.concat(stderr)
  Object.assign(receipt, { stdoutSha256: sha256(out), stderrSha256: sha256(err) })
  await writeFile(join(directory, receipt.stdoutFile), out)
  await writeFile(join(directory, receipt.stderrFile), err)
  await writeFile(join(directory, 'commands.json'), JSON.stringify(commands, null, 2) + '\n')
  console.log(`${prefix}: PID ${receipt.pid}, exit ${receipt.exitCode}, signal ${receipt.signal || 'none'}`)
  if (receipt.exitCode !== 0) throw new Error(`${command} failed: ${err.toString('utf8')}`)
  return out
}

const manifest = { schemaVersion: 1, kind: 'same-checkout-make-build-only', producer: { role: 'mcp_server_engineer', harness: 'Codex', externalCollaboratorReceipt: false }, checkout: kubo, startedAt: new Date().toISOString(), status: 'RUNNING', limitations: ['Local build identity only; no backend compatibility, BE04, lease or live-backend authority is claimed.'] }
try {
  const sourceFiles = (await run('git', ['ls-files', '--cached', '--others', '--exclude-standard', '-z'], { label: 'source-inventory' })).toString().split('\0').filter(path => path && !path.includes('/evidence/') && !path.startsWith('evidence/') && (/\.(?:go|mod|sum|mk)$/.test(path) || path === 'Makefile'))
  const embedDeclarations = []
  for (const path of sourceFiles.filter(path => path.endsWith('.go') && !path.endsWith('_test.go'))) {
    const source = await readFile(join(kubo, path), 'utf8')
    const directives = source.split('\n').flatMap((line, index) => line.startsWith('//go:embed ') ? [{ line: index + 1, directive: line }] : [])
    if (directives.length) embedDeclarations.push({ path, sha256: sha256(Buffer.from(source)), directives })
  }
  const expectedEmbedOwners = ['assets/assets.go', 'mcp/app/embed.go', 'mcp/contract/contract.go', 'mcp/server/confirm/factor_macos.go', 'mcp/ui/catalog/catalog.go']
  if (JSON.stringify(embedDeclarations.map(item => item.path).sort()) !== JSON.stringify(expectedEmbedOwners.sort())) throw new Error('Non-test Go embed owner inventory differs; stop for owner assessment')
  manifest.embedDeclarations = embedDeclarations
  await writeFile(join(directory, 'go-embed-declarations.json'), JSON.stringify(embedDeclarations, null, 2) + '\n')
  const toolchain = async () => {
    const paths = ['/opt/homebrew/opt/go/libexec/bin/go', '/usr/bin/make', '/opt/homebrew/bin/gmake', '/opt/homebrew/opt/go/libexec/bin/gofmt']
    return Object.fromEntries(await Promise.all(paths.map(async path => [path, { physicalPath: await realpath(path), sha256: sha256(await readFile(path)) }])))
  }
  manifest.toolchainBefore = await toolchain()
  const capture = async () => ({ kuboInputs: await kuboInputs(kubo), buildSource: await snapshot(kubo, sourceFiles), embedsAndMake: await snapshot(kubo, ['mk', 'mcp/app/dist', 'mcp/ui/catalog', 'assets', 'mcp/contract', 'mcp/server/confirm/la_prompt.swift', 'cmd/ipfs/Rules.mk', 'plugin/Rules.mk', 'plugin/loader/Rules.mk', 'plugin/plugins/Rules.mk', 'test/Rules.mk', 'bin/Rules.mk'], { optional: ['.tarball'] }) })
  manifest.before = await capture()
  await writeFile(join(directory, 'before.json'), JSON.stringify(manifest.before, null, 2) + '\n')
  manifest.head = (await run('git', ['rev-parse', 'HEAD'], { label: 'git-head' })).toString().trim()
  manifest.goVersion = (await run('go', ['version'], { label: 'go-version' })).toString().trim()
  manifest.makeVersion = (await run('/usr/bin/make', ['--version'], { label: 'make-version' })).toString().split('\n')[0]
  const generated = await run('bash', ['plugin/loader/preload.sh'], { label: 'preload-dry-output' })
  const formatted = await run('gofmt', [], { input: generated, label: 'preload-gofmt-dry-output' })
  const current = await readFile(join(kubo, 'plugin/loader/preload.go'))
  manifest.preloadPreflight = { currentSha256: sha256(current), regeneratedSha256: sha256(formatted), identical: current.equals(formatted), policy: 'Canonical Makefile same-byte regeneration allowed; changed bytes stop without repair.' }
  if (!manifest.preloadPreflight.identical) throw new Error('Makefile preload regeneration would change source; stopped before make build')
  await writeFile(join(directory, 'build-receipt.json'), JSON.stringify(manifest, null, 2) + '\n')
  await run('/usr/bin/make', ['build'], { label: 'make-build' })
  manifest.toolchainAfter = await toolchain()
  if (JSON.stringify(manifest.toolchainBefore) !== JSON.stringify(manifest.toolchainAfter)) throw new Error('Toolchain executable bytes changed during make build; stopped without repair')
  manifest.after = await capture()
  await writeFile(join(directory, 'after.json'), JSON.stringify(manifest.after, null, 2) + '\n')
  manifest.sourceUnchanged = JSON.stringify(manifest.before) === JSON.stringify(manifest.after)
  if (!manifest.sourceUnchanged) throw new Error('Source/build inputs changed during canonical make build; stopped without repair')
  const binary = join(kubo, 'cmd/ipfs/ipfs')
  if ((await lstat(binary)).isSymbolicLink() || await realpath(binary) !== binary) throw new Error('Binary is not same-checkout regular output')
  const bytes = await readFile(binary)
  const buildInfo = await run('go', ['version', '-m', binary], { label: 'make-binary-info' })
  for (const field of ['CurrentCommit=', 'taggedRelease=', 'buildOrigin=']) if (!buildInfo.toString().includes(field)) throw new Error(`Missing Makefile field ${field}`)
  const version = await run(binary, ['version', '--all'], { label: 'kubo-version' })
  manifest.binary = { path: binary, sha256: sha256(bytes), bytes: bytes.length, buildInfoSha256: sha256(buildInfo), versionSha256: sha256(version), version: version.toString().trim() }
  manifest.status = 'PASS'
} catch (error) {
  manifest.status = 'BLOCKED'
  manifest.error = error.message
  try { manifest.afterFailure = await kuboInputs(kubo); await writeFile(join(directory, 'after-failure.json'), JSON.stringify(manifest.afterFailure, null, 2) + '\n') } catch (snapshotError) { manifest.snapshotError = snapshotError.message }
  process.exitCode = 1
} finally {
  manifest.endedAt = new Date().toISOString()
  manifest.commands = commands
  await writeFile(join(directory, 'build-receipt.json'), JSON.stringify(manifest, null, 2) + '\n')
  console.log(JSON.stringify({ status: manifest.status, binary: manifest.binary, error: manifest.error }))
}
