import { spawn } from 'node:child_process'
import { readFile, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
const directory = dirname(fileURLToPath(import.meta.url))
const receipt = JSON.parse(await readFile(join(directory, 'build-receipt.json'), 'utf8'))
const binary = join(receipt.checkout, 'cmd/ipfs/ipfs')
const digest = bytes => createHash('sha256').update(bytes).digest('hex')
const bytes = await readFile(binary)
const command = { argv: [binary, 'version', '--all'], cwd: receipt.checkout, environment: receipt.commands[0].environment, startedAt: new Date().toISOString(), stdoutFile: '009-kubo-version.stdout.txt', stderrFile: '009-kubo-version.stderr.txt' }
const child = spawn(binary, ['version', '--all'], { cwd: command.cwd, env: command.environment, stdio: ['ignore', 'pipe', 'pipe'] })
command.pid = child.pid
const out = [], err = []
child.stdout.on('data', chunk => out.push(chunk)); child.stderr.on('data', chunk => err.push(chunk))
const outcome = await new Promise((resolve, reject) => { child.once('error', reject); child.once('close', (exitCode, signal) => resolve({ exitCode, signal })) })
const stdout = Buffer.concat(out), stderr = Buffer.concat(err)
Object.assign(command, outcome, { endedAt: new Date().toISOString(), stdoutSha256: digest(stdout), stderrSha256: digest(stderr) })
await writeFile(join(directory, command.stdoutFile), stdout)
await writeFile(join(directory, command.stderrFile), stderr)
const info = await readFile(join(directory, '008-make-binary-info.stdout.txt'))
const diagnostic = { schemaVersion: 1, status: 'BLOCKED', reason: receipt.error, binary: { path: binary, sha256: digest(bytes), bytes: bytes.length, buildInfoSha256: digest(info), versionSha256: digest(stdout), version: stdout.toString() }, sourceUnchanged: receipt.sourceUnchanged, kuboInputsSha256: receipt.before.kuboInputs.sha256, buildSourceSha256: receipt.before.buildSource.sha256, embedsAndMakeSha256: receipt.before.embedsAndMake.sha256, command, limitations: receipt.limitations }
await writeFile(join(directory, 'identity-diagnostic.json'), JSON.stringify(diagnostic, null, 2) + '\n')
console.log(JSON.stringify(diagnostic, null, 2))
