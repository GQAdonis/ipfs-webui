import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { readFile, writeFile, realpath } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { kuboInputs } from '../../../../../ipfs-webui/test/boundary/evidence-schema.mjs'
import { sha256, snapshot } from '../../../../../ipfs-webui/scripts/local-artifact.mjs'

const exec = promisify(execFile)
const directory = dirname(fileURLToPath(import.meta.url))
const originalBytes = await readFile(join(directory, 'build-receipt.json'))
const diagnosticBytes = await readFile(join(directory, 'identity-diagnostic.json'))
const original = JSON.parse(originalBytes), diagnostic = JSON.parse(diagnosticBytes)
const kubo = original.checkout
const env = original.commands[0].environment
const run = async (command, args) => (await exec(command, args, { cwd: kubo, env })).stdout
const same = (actual, expected, label) => { if (JSON.stringify(actual) !== JSON.stringify(expected)) throw new Error(`${label} differs; no additive binding delivered`) }
const current = {
  kuboInputs: await kuboInputs(kubo),
  buildSource: await snapshot(kubo, Object.keys(original.before.buildSource.files)),
  embedsAndMake: await snapshot(kubo, ['mk', 'mcp/app/dist', 'mcp/ui/catalog', 'assets', 'mcp/contract', 'mcp/server/confirm/la_prompt.swift', 'cmd/ipfs/Rules.mk', 'plugin/Rules.mk', 'plugin/loader/Rules.mk', 'plugin/plugins/Rules.mk', 'test/Rules.mk', 'bin/Rules.mk'], { optional: ['.tarball'] })
}
same(original.before, original.after, 'Original before/after complete manifests')
same(current, original.after, 'Current complete source/lock/embed manifests')
const head = (await run('git', ['rev-parse', 'HEAD'])).trim()
same(head, original.head, 'Current checkout HEAD')
const binary = join(kubo, 'cmd/ipfs/ipfs')
same(await realpath(binary), binary, 'Same-checkout physical binary path')
same(sha256(await readFile(binary)), diagnostic.binary.sha256, 'Current binary bytes')
const info = await run('go', ['version', '-m', binary])
same(sha256(Buffer.from(info)), diagnostic.binary.buildInfoSha256, 'Current binary buildinfo')
const version = await run(binary, ['version', '--all'])
same(sha256(Buffer.from(version)), diagnostic.binary.versionSha256, 'Current binary version output')
const goVersion = (await run('go', ['version'])).trim()
same(goVersion, original.goVersion, 'Current Go version')
const makeVersion = (await run('/usr/bin/make', ['--version'])).split('\n')[0]
same(makeVersion, original.makeVersion, 'Current Make version')
const make = original.commands.find(item => item.argv.length === 2 && item.argv[0] === '/usr/bin/make' && item.argv[1] === 'build')
if (!make || make.exitCode !== 0 || make.signal || make.timedOut) throw new Error('No successful retained canonical make build command')
const stdout = await readFile(join(directory, make.stdoutFile)), stderr = await readFile(join(directory, make.stderrFile))
same(sha256(stdout), make.stdoutSha256, 'Retained Make stdout')
same(sha256(stderr), make.stderrSha256, 'Retained Make stderr')
for (const field of ['CurrentCommit=', 'taggedRelease=', 'buildOrigin=']) if (!stdout.toString().includes(field)) throw new Error(`Retained Make command omits ${field}`)
const goPath = await realpath('/opt/homebrew/opt/go/libexec/bin/go')
const makePath = await realpath('/usr/bin/make')
same(original.toolchainBefore, original.toolchainAfter, 'Original before/after toolchain executable hashes')
for (const [path, identity] of Object.entries(original.toolchainAfter)) {
  same(await realpath(path), identity.physicalPath, `Current toolchain physical path ${path}`)
  same(sha256(await readFile(path)), identity.sha256, `Current toolchain executable bytes ${path}`)
}
const binding = {
  schemaVersion: 1, kind: 'same-checkout-make-build-artifact-binding', checkout: kubo,
  producer: { role: 'mcp_server_engineer', harness: 'Codex', externalCollaboratorReceipt: false },
  originalReceipt: { path: 'build-receipt.json', sha256: sha256(originalBytes) },
  identityDiagnostic: { path: 'identity-diagnostic.json', sha256: sha256(diagnosticBytes) },
  scope: 'Local same-checkout make-built artifact and immutable retained provenance only; no backend compatibility, BE04, lease, live-backend or prior Claude producer authority.',
  originalMakeCommand: { pid: make.pid, argv: make.argv, exitCode: make.exitCode, stdoutSha256: make.stdoutSha256, stderrSha256: make.stderrSha256 },
  currentVerifiedAt: new Date().toISOString(),
  current: {
    head, kuboInputsSha256: current.kuboInputs.sha256, buildSourceSha256: current.buildSource.sha256,
    embedsAndMakeSha256: current.embedsAndMake.sha256, binarySha256: diagnostic.binary.sha256,
    buildInfoSha256: diagnostic.binary.buildInfoSha256, versionSha256: diagnostic.binary.versionSha256,
    toolchain: { goVersion, makeVersion, go: { path: goPath, sha256: sha256(await readFile(goPath)) }, make: { path: makePath, sha256: sha256(await readFile(makePath)) } }
  },
  limitations: ['Original generic BLOCKED verdict and causal metadata failure remain unchanged.', 'The underlying fresh v2 make build captures all five Go embed owners and verifies toolchain executable hashes before/after; v1 is retained as incomplete historical provenance.', 'No additional build or daemon was run by this additive binding script.']
}
await writeFile(join(directory, 'artifact-binding-receipt.json'), JSON.stringify(binding, null, 2) + '\n')
same(sha256(await readFile(join(directory, 'build-receipt.json'))), binding.originalReceipt.sha256, 'Unchanged original receipt')
same(sha256(await readFile(join(directory, 'identity-diagnostic.json'))), binding.identityDiagnostic.sha256, 'Unchanged diagnostic')
console.log(JSON.stringify({ path: join(directory, 'artifact-binding-receipt.json'), sha256: sha256(await readFile(join(directory, 'artifact-binding-receipt.json'))), current: binding.current }, null, 2))
