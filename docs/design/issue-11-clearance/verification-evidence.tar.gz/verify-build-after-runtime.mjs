import { readFile, writeFile, mkdir } from 'node:fs/promises'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { makeBinaryIdentity } from '../../../../ipfs-webui-issue10-publication/test/helpers/owned-kubo.mjs'
import { Processes, isolatedEnvironment } from '../../../../ipfs-webui-issue10-publication/test/boundary/processes.mjs'
import { sha256 } from '../../../../ipfs-webui-issue10-publication/scripts/local-artifact.mjs'

const directory = dirname(fileURLToPath(import.meta.url))
const kubo = resolve(directory, '../../..')
const output = join(directory, 'post-runtime-build-validation')
await mkdir(output, { recursive: false })
const processes = new Processes(join(output, 'commands'))
const receipt = { schemaVersion: 1, kind: 'complete-build-validation-after-runtime', startedAt: new Date().toISOString(), scriptSha256: sha256(await readFile(fileURLToPath(import.meta.url))), cleanup: [] }
try {
  receipt.identity = await makeBinaryIdentity({ kubo, processes, env: isolatedEnvironment(join(output, 'unused-repo'), kubo), makeBuildReceipt: join(directory, 'node-delivery-v2/artifact-binding-receipt.json') })
  receipt.status = 'PASS'
} catch (error) { receipt.status = 'BLOCKED'; receipt.error = error.message; process.exitCode = 1 } finally {
  try { await processes.stop() } catch (error) { receipt.cleanup.push(error.message); receipt.status = 'BLOCKED'; process.exitCode = 1 }
  receipt.endedAt = new Date().toISOString()
  receipt.commands = processes.commands
  await writeFile(join(output, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' })
}
console.log(JSON.stringify({ status: receipt.status, cleanup: receipt.cleanup, receipt: join(output, 'receipt.json') }))
