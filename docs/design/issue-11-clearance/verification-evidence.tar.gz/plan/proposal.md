# Proposal

## Why

WebUI #11 tracks the remaining UI-112 evidence after #10's verified family-isolation correction. Eight node-hosted shell/decision contributions have not executed, and 384 retained contrast incomplete occurrences lack exact rendered-node measurements.

## What Changes

- Obtain a new build-only owner-role delivery of `make build` from the exact isolated Kubo source checkout, recording provenance without backend source changes or external binary substitution.
- Repair the observed frontend binary-identity check for canonical `-trimpath` builds using an explicitly supplied, fully source/binary/log-bound same-checkout build receipt; preserve the original metadata route where actual injected fields are present.
- Execute the existing production-path shell and node-backed decision presentation registrations, preserving all five families, four slots, both themes and eight authored shell widths.
- Add evidence-owned runtime contrast collection/dispositions for every original incomplete occurrence, retaining foreground/composited background, opacity/filter ancestry, geometry and hit testing; expose virtual rows rather than assessing unrelated visible rows.
- Validate or normally refresh frontend export and Desktop assembly as required by actual source changes; retain failures and source/runtime/PNG/cleanup bindings and obtain independent review.

## Capabilities

### New Capabilities

None. This is build/evidence tooling and completion of existing verification requirements.

### Modified Capabilities

None. `skip_specs: true` records that the current UI-112 oracle, family membership, contract, production API and feature behavior remain unchanged. The measured build-provenance predicate correction below changes verification tooling, not the tested product or required provenance guarantees. Any other measured production defect requires an explicit owner-routed correction before source edits.

## Impact

Planning: this change only. Build output: isolated `cmd/ipfs/ipfs`, owned by native `mcp_server_engineer` for this task, plus receipts under `evidence/agentic-ui-frontend/issue11-clearance/node-delivery/`. Runtime results live under `evidence/agentic-ui-frontend/issue11-clearance/contrast/`; observation helper source is owned by the contrast UI agent in the publication WebUI checkout. Existing source-bound frontend publication/migration work remains with root and is not silently overwritten or treated as these test results.

No backend/Go/module/contract edits, lease adoption, privileged Desktop changes, fallback hosts, weakened validators, dropped widths/families, telemetry, or deployment are proposed. The earlier #10 no-build scope remains historical; the operator's explicit #11 work now routes the missing build to its owning role. A locally produced owner-role build is labeled as such, never presented as a prior Claude delivery or compatibility receipt. Full phase, live consent/effects/models and physical native/assistive-technology proof remain separate.

## Measured tooling correction grant

The canonical Makefile build exited zero and produced binary `792cb3b214b54daafd8ae432113a8a22c5cf6e0df7c4a15c38de60b28f52eccf`, with identical before/after backend/source/embedded inputs. The retained `go version -m` lacks `-ldflags` because canonical `-trimpath` suppresses that metadata; the observed local Go source cites issue 52372. The original frontend identity predicate therefore rejects a correctly built binary. This is a concrete verification defect, not missing backend implementation.

Root routes the minimal correction to native `ui_ux_engineer`: publication WebUI `test/helpers/owned-kubo.mjs`, new `test/boundary/make-build-receipt.mjs`, new `test/boundary/make-build-receipt.test.js`, new `test/boundary/make-build-receipt-negative.test.js`, only the optional test-only `makeBuildReceipt` input wiring in `scripts/agentic-boundary.mjs` and its existing config parser/usage, and corresponding `test/boundary/OPERATIONS.md` instructions. These exact paths reflect root's assignment confirmed by the provenance worker. All other runner behavior, source/export validators, credentials, leases and UI-112 predicates remain unchanged. No receipt JSON may supply an execution authority flag or replace current-byte checks. Tests must prove the old canonical-build rejection and the unchanged successful metadata route, plus malformed, stale, forged and foreign-source failures.

## Bounded security and observation follow-through

Independent finding `I11-SEC-01` identified omitted compiled embed inputs in the first receipt verifier: `assets/init-doc` and contract JSON/directories embedded by `mcp/contract/contract.go`. The same six-file provenance grant extends to complete `assets/**`, `mcp/contract/**` and explicit native Swift input capture, plus a fail-closed check that every current non-test Go embed declaration resolves entirely into captured before/after/current bytes. Unsupported embed syntax or uncovered targets are blockers. Add contract/assets tamper regressions and retain the original insufficient receipt unchanged. A genuinely new native-owner build with complete before/build/after captures is required; current-only reconstruction cannot attest the earlier build.

The resulting v2 delivery and source freeze are recorded in `design.md` as newly produced evidence, subject to independent confirmation. No backend source was edited. The first WU SIGTERM diagnostic and first SU metadata blocker remain immutable. The next SU snapshot materializes Desktop installed dependencies as real directories to satisfy its unchanged strict metadata checks; remaining ignored dependency caches may link only where existing checks permit.

The first contrast runtime retains 376 passing occurrences, zero failures and eight unknowns. An observed BODY overflow-propagation error in the supplemental observer's clipping calculation justifies a minimal geometry correction and regression within the already owned contrast-helper paths. It grants no fixture, production or accessibility-predicate changes. Preserve the first runtime; new observations must identify themselves as changed-observer confirmation.

## Observed production shell failure and bounded owner route

Real WU `boundary-v2/runs/webui-2026-10-21T23-33-07-525Z-3972` records 19 passing UI-112 family/slot outcomes and a failing shell/axe contribution at dark theme, width 540; eight light widths and dark 320/375/539 precede it successfully. The current shell driver asserts before retaining full failing axe detail and PNG. The violation's rule/node/cause is not yet established; this plan does not assume a palette or CSS defect.

Root assigns native `ui_ux_engineer` (the contrast/evidence owner) read-only diagnosis through the actual owned node, current exported production shared-path shell and unchanged axe rules, writing only `evidence/agentic-ui-frontend/issue11-clearance/shell-axe-diagnostic/` while any current boundary remains active. Retain complete violation/incomplete detail, target DOM/computed styles/geometry, current source/artifact/runtime bindings and a failure PNG before exact owned cleanup. This diagnostic is not a substituted acceptance run.

After active WU/SU runs terminate and their evidence is retained, root may grant only the confirmed responsible publication-WebUI presentation file(s) and a meaningful existing or new regression test. The owner must identify the exact rule, node, causal behavior and file paths in the diagnostic handoff; root records those paths in this change before source edits. Also permit the narrowly evidenced retention repair in `test/boundary/chat-runtime/shell-accessibility.mjs`: record complete original axe results and failure PNG before the existing assertion, preserving its tags, exercised-passes/zero-violations predicate, every width/theme and all other assertions. No broad palette adjustment, fallback host, fixture masking or waiver is authorized.

Complete the minimum coherent correction, prove causal failure then unchanged green, freeze sources, regenerate through normal export/assembly and run full WU followed by SU against the same new artifact. Rebind/refresh all 384 contrast observations to current changed sources/artifacts; the existing passing runtime is historical if its bindings change. Preserve the first production failure and all intermediate diagnostics. No Go/backend/contract/privileged Desktop changes are included.

## Confirmed shell defect: exact presentation grant

WU/SU executions are terminal. The retained actual production dark-540 diagnostic identifies normal 14.5px Remove-reference text (`.iu-btn--text`) at `#e96a12` over composer `#2d2c2a`, 4.34:1 versus the required 4.5:1. Publication `src/agent-chat/ComposedChat.jsx` appends the host override `.praxis-composer{background:var(--control)}`. Existing `DESIGN.md` reserves `raised` for nested surfaces and explicitly excludes dark `accent-text` on `control`; the correction follows established design authority rather than changing the palette. The same diagnostic retains an ARIA incomplete for the named `.praxis-suggestions` div without a role.

Root's exact native UI owner grant is publication WebUI `src/agent-chat/ComposedChat.jsx` (change only composer fill from `var(--control)` to `var(--raised)`), `src/shell/Home.jsx` (add `role='group'` to the existing `aria-label='Draft suggestions'` container), and `src/shell/Home.test.jsx` (new semantic regression proving the accessible named group and preserved suggestion behavior). The already granted `test/boundary/chat-runtime/shell-accessibility.mjs` change retains full axe output and failure PNG before the identical assertion. The unchanged actual browser axe predicate and retained production failure supply causal red for contrast; no CSS-string mirror test is needed. Confirm green using the actual corrected production shell, not token arithmetic or fixture overrides.

No other presentation, shared Kubo component/token, backend or privileged Desktop path is granted. Preserve first-failure evidence and refresh through the planned full current-artifact verification sequence. SU's snapshot preparation also copies all current assets and preserves installed-cache symlink semantics inside its valid dependency prefix; the earlier missing locale `en.json` timeout remains retained as a setup failure, never an application PASS.
