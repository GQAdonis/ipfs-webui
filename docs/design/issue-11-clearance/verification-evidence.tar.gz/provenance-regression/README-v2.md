# Complete embed coverage correction (I11-SEC-01)

This supersedes the original source freeze. Independent security review found that the initial proof omitted non-Go `mcp/contract` embeds and `assets/init-doc`. The original green tests and frozen source manifest remain historical; they are not evidence that those inputs were bound.

The corrected `embedsAndMake` capture includes full `assets`, full `mcp/contract`, native `mcp/server/confirm/la_prompt.swift`, and the existing app views, UI catalog and Make roots. The helper also inspects every non-test `go:embed` declaration in the complete source inventory, expands each supported directive root and requires all corresponding bytes already present in the captures. New uncovered targets or unsupported syntax block. Inspection found five local non-test declaration locations: initial documentation, contract, app views, UI catalog and native confirmation Swift. Test CLI PEM fixtures remain in the existing full `test/cli` capture.

The native build owner produced a genuinely new `node-delivery-v2` before/build/after proof and additive binding; the earlier inputs were never retrospectively attested. Updated actual-helper regression accepts that fresh v2 proof and explicitly rejects the historical incomplete v1 proof. New portable regressions reject contract, documentation and Swift tampering plus a newly introduced uncaptured embed target. `green-v2.*` records 31/31 passing tests; `lint-v2.*` records ESLint success. Current exact source hashes and retained logs are bound by `source-freeze-v2.json`.

The UI subagent did not run export, browsers, daemons or builds. No backend source or existing export/assembly validator was changed.
