import assert from 'node:assert/strict'
import { readFile, writeFile, lstat, mkdir, copyFile, readdir, symlink, cp } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { sourceInputs, sharedArtifacts, assertLocalWebuiExport } from '../../../../ipfs-webui-issue10-publication/scripts/local-artifact.mjs'
import { desktopInputs, kuboInputs } from '../../../../ipfs-webui-issue10-publication/test/boundary/evidence-schema.mjs'

const directory = dirname(fileURLToPath(import.meta.url))
const parents = resolve(directory, '../../../..')
const origins = { 'ipfs-webui': join(parents, 'ipfs-webui-issue10-publication'), kubo: join(parents, 'kubo'), 'ipfs-desktop': join(parents, 'ipfs-desktop') }
const destination = join(directory, 'su-source-snapshot-final')
await mkdir(destination, { recursive: false })
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex')
const transfers = {}, caches = []
async function copy (repo, path) {
  if (repo === 'ipfs-desktop' && (path === 'assets/webui' || path.startsWith('assets/webui/'))) return
  if (path.split('/').some(part => ['node_modules', '.git', '.cache', 'evidence', '.DS_Store'].includes(part)) || path === 'cmd/ipfs/ipfs') return
  const from = join(origins[repo], path), to = join(destination, repo, path)
  let stat
  try { stat = await lstat(from) } catch (error) { if (error.code === 'ENOENT') return; throw error }
  if (stat.isSymbolicLink()) throw new Error(`Source/artifact symlink refused: ${from}`)
  if (stat.isDirectory()) { await mkdir(to, { recursive: true }); for (const child of (await readdir(from)).sort()) await copy(repo, path ? `${path}/${child}` : child); return }
  if (!stat.isFile()) throw new Error(`Unsupported source ${from}`)
  await mkdir(dirname(to), { recursive: true })
  const before = sha256(await readFile(from))
  await copyFile(from, to)
  const after = sha256(await readFile(from)), copied = sha256(await readFile(to))
  assert.equal(before, after, `Source drift ${from}`); assert.equal(before, copied, `Copy mismatch ${to}`)
  transfers[`${repo}/${path}`] = { origin: from, destination: to, sha256: before, bytes: stat.size }
}
const before = { source: await sourceInputs(origins['ipfs-webui'], origins.kubo), shared: await sharedArtifacts(origins.kubo), desktop: await desktopInputs(origins['ipfs-desktop']), kubo: await kuboInputs(origins.kubo) }
const artifact = await assertLocalWebuiExport({ root: origins['ipfs-webui'], kubo: origins.kubo })
// Copy complete package trees, including their exact current generated artifacts.
for (const path of ['src', 'public', '@types', 'scripts', 'test', 'patches', 'vendor', 'build', 'package.json', 'package-lock.json', '.npmrc', '.tool-versions', 'index.html', 'vite.config.js', 'vitest.config.js', 'tsconfig.json', 'postcss.config.js', 'LICENSE']) await copy('ipfs-webui', path)
for (const path of ['src', 'scripts', 'test', 'assets', 'package.json', 'package-lock.json', '.npmrc', '.tool-versions', 'LICENSE', 'LICENSE-MIT', 'LICENSE-APACHE']) await copy('ipfs-desktop', path)
for (const path of ['assets', 'cmd', 'core', 'config', 'plugin', 'repo', 'client', 'test/cli', 'mcp/server', 'mcp/ui', 'mcp/chat', 'mcp/app', 'mcp/webmcp', 'mcp/contract', 'go.mod', 'go.sum', 'Makefile', 'version.go', 'Rules.mk', 'test/dependencies/go.mod', 'test/dependencies/go.sum', 'docs/examples/kubo-as-a-library/go.mod', 'docs/examples/kubo-as-a-library/go.sum', 'LICENSE', 'LICENSE-MIT', 'LICENSE-APACHE', 'PRODUCT.md', 'DESIGN.md', '.kbd-orchestrator/phases/agentic-ui-frontend/adopted-contract.json', '.kbd-orchestrator/phases/agentic-ui-frontend/plan.json']) await copy('kubo', path)
for (const [repo, path] of [['ipfs-webui', 'node_modules'], ['ipfs-webui', 'vendor/ipld-explorer-components/node_modules'], ['ipfs-desktop', 'node_modules'], ...['ui', 'chat', 'app', 'webmcp'].map(name => ['kubo', `mcp/${name}/node_modules`])]) {
  const from = join(origins[repo], path), to = join(destination, repo, path)
  await lstat(from); await mkdir(dirname(to), { recursive: true });
  if (repo === 'ipfs-desktop') await cp(from, to, { recursive: true, dereference: false, verbatimSymlinks: true }); else await symlink(from, to, 'dir')
  caches.push({ mode: repo === 'ipfs-desktop' ? 'materialized-copy-for-strict-renderer-prefix' : 'ignored-cache-link', purpose: 'Ignored installed dependency cache only; excluded from source identity', origin: from, destination: to })
}
const after = { source: await sourceInputs(origins['ipfs-webui'], origins.kubo), shared: await sharedArtifacts(origins.kubo), desktop: await desktopInputs(origins['ipfs-desktop']), kubo: await kuboInputs(origins.kubo) }
assert.deepEqual(after, before, 'Origins changed while snapshotting')
const copied = { source: await sourceInputs(join(destination, 'ipfs-webui'), join(destination, 'kubo')), shared: await sharedArtifacts(join(destination, 'kubo')), desktop: await desktopInputs(join(destination, 'ipfs-desktop')), kubo: await kuboInputs(join(destination, 'kubo')) }
assert.deepEqual(copied, before, 'Snapshot changed source/artifact identity')
const copiedArtifact = await assertLocalWebuiExport({ root: join(destination, 'ipfs-webui'), kubo: join(destination, 'kubo') })
assert.equal(copiedArtifact.artifactSha256, artifact.artifactSha256)
for (const transfer of Object.values(transfers)) {
  assert.equal(sha256(await readFile(transfer.origin)), transfer.sha256, `Origin changed after transfer: ${transfer.origin}`)
  assert.equal(sha256(await readFile(transfer.destination)), transfer.sha256, `Destination changed after transfer: ${transfer.destination}`)
}
await writeFile(join(directory, 'su-source-transfer-final.json'), JSON.stringify({ schemaVersion: 1, kind: 'source-identical-SU-sibling-snapshot', generatedAt: new Date().toISOString(), destination, origins, before, after, copied, artifactSha256: artifact.artifactSha256, transfers, caches, limitation: 'No copied Kubo binary and no node authority. Standard SU assembly regenerates Desktop presentation output and binds actual runtime files.' }, null, 2) + '\n', { flag: 'wx' })
console.log(JSON.stringify({ destination, files: Object.keys(transfers).length, artifactSha256: artifact.artifactSha256, sourceIdentity: 'PASS' }))
