import { spawn } from 'node:child_process'
import { readFile, writeFile, mkdir } from 'node:fs/promises'
import { dirname, join, resolve } from 'node:path'
import { createHash } from 'node:crypto'

const [directoryArg, cwdArg, command, ...args] = process.argv.slice(2)
if (!directoryArg || !cwdArg || !command) throw new Error('Usage: run-command.mjs <new-evidence-directory> <cwd> <command> [args]')
if (process.version !== 'v26.5.0') throw new Error('Pinned Node 26.5.0 required')
const directory = resolve(directoryArg), cwd = resolve(cwdArg)
await mkdir(directory, { recursive: false })
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex')
const environment = { PATH: `${dirname(process.execPath)}:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin`, HOME: process.env.HOME, CI: '1', COREPACK_ENABLE_AUTO_PIN: '0', IPFS_TELEMETRY: 'off', DO_NOT_TRACK: '1' }
const receipt = { schemaVersion: 1, kind: 'actual-local-command', argv: [command, ...args], cwd, environment, node: { executable: process.execPath, version: process.version, sha256: sha256(await readFile(process.execPath)) }, startedAt: new Date().toISOString() }
const child = spawn(command, args, { cwd, env: environment, stdio: ['ignore', 'pipe', 'pipe'] })
receipt.pid = child.pid
const out = [], err = []
child.stdout.on('data', bytes => out.push(bytes))
child.stderr.on('data', bytes => err.push(bytes))
const result = await new Promise(resolve => { child.once('error', error => resolve({ exitCode: null, error: error.message })); child.once('close', (exitCode, signal) => resolve({ exitCode, signal })) })
const stdout = Buffer.concat(out), stderr = Buffer.concat(err)
await writeFile(join(directory, 'stdout.txt'), stdout, { flag: 'wx' })
await writeFile(join(directory, 'stderr.txt'), stderr, { flag: 'wx' })
Object.assign(receipt, result, { endedAt: new Date().toISOString(), stdout: { path: 'stdout.txt', sha256: sha256(stdout), bytes: stdout.length }, stderr: { path: 'stderr.txt', sha256: sha256(stderr), bytes: stderr.length }, status: result.exitCode === 0 ? 'PASS' : 'FAIL' })
await writeFile(join(directory, 'command.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' })
console.log(JSON.stringify({ directory, pid: receipt.pid, exitCode: receipt.exitCode, status: receipt.status }))
process.exitCode = result.exitCode === 0 ? 0 : 1
