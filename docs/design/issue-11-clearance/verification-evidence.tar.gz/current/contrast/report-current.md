# Current export: retained contrast occurrences

Runtime-3 independently remeasured the original **384 retained occurrences from sixteen reports** on current normal export `b9c25a7631a0d37d1353efd8f38be7a059f9f63c22f269a3112c1c7e3cc5d69c`: **384 supported computed PASS, 0 FAIL, 0 UNKNOWN**, exit0, cleanup[]. No additional axe invocation was performed by this helper. Original axe incomplete records and prior runs remain unchanged.

| Original reason / assessed case | Occurrences | Current supported disposition |
| --- | ---: | --- |
| Generated pseudo-element | 268 | Actual strip rectangles do not intersect target text; recorded opaque background and foreground meet contrast requirements. |
| Virtual event overscan | 108 | Each exact selector/content target is natively scrolled, rebound and assessed inside its real clipped viewport with three unobscured point hits per text range. |
| Host fixture heading | 8 | Actual BODY overflow propagates to viewport under recorded root/body conditions; all heading lines are visible and hit-tested. |

The minimum observed ratio remains **4.908531945906348:1**, exceeding the applicable 4.5:1 threshold. The headings measure 16.74569264768206:1 in light and 17.621719237053668:1 in dark against 3:1. Ratios are not rounded for decisions. No disabled-control exception is used. Unsupported geometry, masks, images, filters, blend modes, opacity layers, occlusion or changing paint would remain UNKNOWN.

`runtime-3-dispositions.json` contains all384 individual dispositions, original report SHA256/node index and selector, target identity, current measurement-report binding, PNG binding, foreground/background colors, ratio/threshold, pseudo disposition, hit counts and rationale. The sixteen immutable runtime reports retain complete before/after scroll facts, shadow-aware hits, ancestry styles, viewport clipping, overflow propagation and post-capture stability checks. `summarize-current.py` verified every report and all384 PNG hashes, every visibility/hit predicate and each ratio before generating the index.

The author opened five current captures: light375 inbox and activity headings, dark1440 activity heading, dark1440 minimum-ratio table header and light375 scrolled event10. The activity heading was also reopened individually at original detail: its full two-line H1 is present and matches window scroll0 and six H1 hit points. These are representative visual checks, not individual visual review of every screenshot. Independent review is separate.

The first run remains 376 PASS and eight UNKNOWN. Its false BODY-box clipping was corrected using [CSS Overflow 3 section 3.3](https://www.w3.org/TR/css-overflow-3/#overflow-propagation), then validated with four tests including real browser negative cases for ordinary clipping, contained BODY and an obscuring overlay. Runtime-2 cleared all384 on the preceding d33 export. Runtime-3 provides fresh measurements after the separately verified production composer/ARIA fixes; it does not reuse prior results as current measurements.

| Current evidence | SHA256 |
| --- | --- |
| `runtime-3/summary.json` | `d682a4dae0d87ce333c4607171364b50de71b04e56e50e8270d4b7e204bd71dc` |
| `runtime-3-dispositions.json` | `9ef960500eaec78400a3e733fd25d5a48959c547924dd918bcb77531276181f6` |

Strict export verification passed before and after the run. The manifest, helper files, pinned browser executable and fixture producer sources are bound in the runtime summary and its records. Earlier reports and hash indexes remain immutable.

This report covers only the original sixteen/384 supplemental production-component fixture occurrences. Additional current WU reports must be inventoried and assessed separately; no result transfers to new targets. The production shell's causal 4.34→5:1 correction is documented separately in `../shell-axe-diagnostic/confirmation.json`. Existing fixture composition overrides remain. This evidence does not certify deployed layout, full WCAG conformance, physical assistive technology, native presence or backend execution.
