"""Index immutable supplemental contrast records; does not run a browser or axe."""
import collections
import hashlib
import json
import pathlib

p = pathlib.Path(__file__).parent
r = p / 'runtime-3'

def bind(f):
    return {'path': str(f), 'sha256': hashlib.sha256(f.read_bytes()).hexdigest()}

s = json.loads((r / 'summary.json').read_text())
assert s['counts'] == {'PASS': 384, 'FAIL': 0, 'UNKNOWN': 0}
assert not s['cleanup'] and not s.get('error')
rows = []
counts = collections.Counter()
views = ['0377-inbox-inbox-axe-inbox-light-375-node-0.png', '0378-inbox-inbox-axe-activity-light-375-node-0.png', '0384-inbox-inbox-axe-activity-dark-1440-node-0.png', '0107-a2ui-a2ui-axe-dark-1440-node-14.png', '0183-context-context-axe-light-375-node-62.png']
for entry in s['reports']:
    f = pathlib.Path(entry['binding']['path'])
    assert bind(f) == entry['binding']
    report = json.loads(f.read_text())
    for n in report['nodes']:
        m, a = n['measurement'], n['assessment']
        messages = [x.get('data', {}).get('messageKey') for x in n['originalChecks']]
        assert n['status'] == 'PASS' and n['paintStableDuringCapture'] and not n['reasons']
        assert all(t['fullyVisible'] and len(t['hits']) == 3 and all(h['targetOrDescendant'] for h in t['hits']) for t in m['textSamples'])
        assert a['ratio'] >= a['threshold']
        assert all(x['intersectsText'] is False for x in a['pseudoEvidence'])
        assert bind(pathlib.Path(n['screenshot']['path'])) == n['screenshot']
        if 'pseudoContent' in messages:
            category = 'non-overlapping-pseudo-element'
            rationale = 'Actual generated strip rectangles do not intersect any target text range. Unobscured hits and observed foreground/opaque background meet the applicable ratio.'
        elif report['family'] == 'context':
            category = 'virtual-event-row-after-scroll'
            rationale = 'Exact virtual-row selector and content rebound after native scrolling. Every measured text range is inside its clipped viewport with three unobscured point hits. Offscreen measurements do not determine PASS.'
        else:
            category = 'host-heading-viewport-overflow'
            rationale = 'BODY overflow propagates to viewport with HTML overflow visible and containment none. All heading lines are inside viewport and hit heading at three points per line. Observed colors meet large-text threshold.'
            assert m['overflowPropagation']['source']['tag'] == 'BODY'
            assert m['overflowPropagation']['rootStyle']['contain'] == 'none'
            assert m['overflowPropagation']['bodyStyle']['contain'] == 'none'
        counts[category] += 1
        rows.append({'id': report['name'] + ':' + str(n['originalNodeIndex']), 'originalReport': report['original'], 'originalNodeIndex': n['originalNodeIndex'], 'originalTarget': n['originalTarget'], 'originalHtml': n['originalHtml'], 'originalMessageKeys': messages, 'runtimeReport': entry['binding'], 'screenshot': n['screenshot'], 'theme': report['theme'], 'width': report['width'], 'category': category, 'disposition': 'SUPPORTED-COMPUTED-CONTRAST-PASS', 'rationale': rationale, 'originalAxeIncompletePreserved': True, 'targetBinding': n['afterScrollBinding'], 'ratio': a['ratio'], 'threshold': a['threshold'], 'foreground': a['foreground'], 'effectiveForeground': a['effectiveForeground'], 'background': a['background'], 'pseudoEvidence': a['pseudoEvidence'], 'textRangeCount': len(m['textSamples']), 'hitCount': sum(len(t['hits']) for t in m['textSamples']), 'allTextRangesVisibleAndUnobscured': True, 'paintStableDuringCapture': True, 'individuallyVisuallyOpened': pathlib.Path(n['screenshot']['path']).name in views})
assert len(rows) == 384
assert dict(counts) == {'non-overlapping-pseudo-element': 268, 'virtual-event-row-after-scroll': 108, 'host-heading-viewport-overflow': 8}
result = {'schemaVersion': 1, 'kind': 'retained-384-contrast-dispositions', 'scope': 'Only original sixteen contrast incomplete reports from confirmation-summary; no inference for new WU reports.', 'runtimeSummary': bind(r / 'summary.json'), 'priorRuntimeSummary': bind(p / 'runtime-1/summary.json'), 'diagnosis': bind(p / 'runtime-1-diagnosis.json'), 'counts': dict(counts), 'total': len(rows), 'minimumRatio': min(x['ratio'] for x in rows), 'maximumRatio': max(x['ratio'] for x in rows), 'sourceBinding': s['export'], 'helperBindings': s['helperBindings'], 'browser': s['browser'], 'visualSpotChecks': [bind(r / 'screenshots' / v) for v in views], 'independentVisualReview': 'Required separately; author spot checks are not independent review.', 'newCurrentWuReports': 'NOT ASSESSED: outside original sixteen/384 scope; must inventory separately.', 'fullWcagCertification': False, 'physicalAssistiveTechnologyClaim': False, 'originalAxeIncompleteRecordsChanged': False, 'newAxeInvocations': 0, 'cleanupErrors': s['cleanup'], 'dispositions': rows}
(p / 'runtime-3-dispositions.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'counts': dict(counts), 'summary': bind(r / 'summary.json'), 'dispositions': bind(p / 'runtime-3-dispositions.json')}, indent=2))
