import { useRef, useState, type ReactNode } from 'react';
import { Button, Tabs, TabsContent, TabsList, TabsTrigger, type InspectorEvent, type RunFacts } from '@gqadonis/ipfs-mcp-ui';
import { INSPECTOR_LIMITS, type RunInspectorSnapshot } from './run-inspector';

export interface RunInspectorProps { readonly snapshot: RunInspectorSnapshot; readonly label?: string }
const NOT_REPORTED = 'Not reported by this server';
const phases = { idle: 'No accepted run inspected', running: 'Running', waiting_approval: 'Waiting for approval', finished: 'Run finished', failed: 'Run reported an error', cancelled: 'Stopped locally', unknown: 'Outcome unknown' } as const;
const source = (value: string | undefined) => value?.replaceAll('_', ' ') ?? NOT_REPORTED;
function Fact({ label, children }: { readonly label: string; readonly children?: ReactNode }) {
  return <div className="grid gap-s1 border-b border-border py-s2"><dt className="text-muted-foreground">{label}</dt><dd className="m-0 break-words [overflow-wrap:anywhere]">{children ?? NOT_REPORTED}</dd></div>;
}
function Overview({ snapshot }: RunInspectorProps) {
  const facts = snapshot.facts;
  return <>
    <p className="text-muted-foreground">Only this accepted run is inspected. Approval and a finished run do not prove that an operation succeeded.</p>
    <dl>
      <Fact label="Run state">{snapshot.phase === 'waiting_approval' ? snapshot.events.at(-1)?.label ?? phases[snapshot.phase] : phases[snapshot.phase]}</Fact>
      <Fact label="Backend">{facts?.backend?.kind}</Fact>
      <Fact label="Model">{facts?.backend?.model}</Fact>
      <Fact label="Placement">{facts?.backend?.placement}</Fact>
      <Fact label="Backend host">{facts?.backend?.host}</Fact>
      <Fact label="Backend source">{source(facts?.provenance?.backend)}</Fact>
      <Fact label="Memory">{facts?.memory ? facts.memory.scope === 'none' ? 'None reported for this run' : source(facts.memory.scope) : undefined}</Fact>
      {facts?.memory?.description ? <Fact label="Memory description">{facts.memory.description}</Fact> : null}
      <Fact label="Memory source">{source(facts?.provenance?.memory)}</Fact>
      <Fact label="Acknowledged egress hosts">{facts?.egress ? facts.egress.acknowledged_hosts.length ? facts.egress.acknowledged_hosts.join(', ') : 'None reported for this run' : undefined}</Fact>
      <Fact label="Egress source">{source(facts?.provenance?.egress)}</Fact>
      {snapshot.activityId ? <Fact label="Reported activity">{snapshot.activityId}</Fact> : null}
    </dl>
    <p className="text-muted-foreground">Facts describe the server’s retained run snapshot. They do not grant permission or disclose an unreported backend’s behavior.</p>
  </>;
}
function Context({ facts }: { readonly facts?: RunFacts }) {
  const references = facts?.context_snapshot;
  return <>
    <p className="text-muted-foreground">The server’s accepted context snapshot, rather than the page or selections currently in your composer. References are text only here.</p>
    {references === undefined ? <p>{NOT_REPORTED}</p> : references.length === 0 ? <p>No references in the reported accepted snapshot.</p> : <ul className="grid list-none gap-s2 p-0">
      {references.map(reference => <li key={reference.id} className="rounded-control border border-border p-s2 [overflow-wrap:anywhere]">
        <p className="font-semibold">{reference.provenance === 'page' ? 'Page reference' : 'User reference'}</p>
        <dl>
          {reference.route !== undefined ? <Fact label="Route">{reference.route}</Fact> : null}
          {reference.cid !== undefined ? <Fact label="CID">{reference.cid}</Fact> : null}
          {reference.path !== undefined ? <Fact label={reference.path_kind === 'mfs' ? 'MFS path' : 'IPFS / IPNS path'}>{reference.path}</Fact> : null}
        </dl>
      </li>)}
    </ul>}
    <p className="text-muted-foreground">Source: {source(facts?.provenance?.context_snapshot)}</p>
  </>;
}
function PromptPlan({ facts }: { readonly facts?: RunFacts }) {
  return <>
    <p className="text-muted-foreground">Actual reported tool offer and prompt digest. No prompt text, inferred token budget or current settings are substituted.</p>
    <dl>
      <Fact label="Offered tool count">{facts?.offered_tools?.length}</Fact>
      <Fact label="Tool scope">{facts?.tool_scope === undefined ? undefined : facts.tool_scope === 'kubo_contract' ? 'Kubo contract' : 'Backend report'}</Fact>
      <Fact label="Tool offer source">{source(facts?.provenance?.offered_tools)}</Fact>
      <Fact label="Reported catalog size">{facts?.catalog_size}</Fact>
      <Fact label="Catalog source">{source(facts?.provenance?.catalog_size)}</Fact>
      <Fact label="System prompt digest">{facts?.system_prompt_digest ? <code>{facts.system_prompt_digest}</code> : undefined}</Fact>
      <Fact label="Prompt digest source">{source(facts?.provenance?.system_prompt_digest)}</Fact>
    </dl>
    <h4 className="mt-s3 font-ui-heading font-semibold">Offered tools</h4>
    {facts?.offered_tools === undefined ? <p>{NOT_REPORTED}</p> : facts.offered_tools.length === 0 ? <p>No tools offered in the reported snapshot.</p> : <ul className="list-inside list-disc [overflow-wrap:anywhere]">{facts.offered_tools.map(tool => <li key={tool}><code>{tool}</code></li>)}</ul>}
    <p className="mt-s3 text-muted-foreground">A catalog total is not the number available to this principal. UAR tool, prompt and memory facts require a validated backend report.</p>
  </>;
}
const ROW_HEIGHT = 168, WINDOW_SIZE = 8, OVERSCAN = 3;
function EventRow({ event, index, total, virtual }: { readonly event: InspectorEvent; readonly index: number; readonly total: number; readonly virtual: boolean }) {
  return <li tabIndex={virtual ? 0 : undefined} aria-posinset={index + 1} aria-setsize={total} className="border-b border-border py-s2 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring" style={virtual ? { position: 'absolute', top: index * ROW_HEIGHT, height: ROW_HEIGHT, width: '100%', overflow: 'auto' } : undefined}>
    <p className="font-semibold">{event.label ?? source(event.type)}</p>
    {event.tool ? <p className="break-words"><code>{event.tool}</code></p> : null}
    <p className="text-muted-foreground">{event.at ? <time dateTime={event.at}>{event.at}</time> : 'Time not reported'}</p>
  </li>;
}
function Events({ snapshot }: RunInspectorProps) {
  const viewport = useRef<HTMLDivElement>(null);
  const [offset, setOffset] = useState(0);
  const virtual = snapshot.events.length > INSPECTOR_LIMITS.virtualizeAfter;
  const first = virtual ? Math.min(Math.floor(offset / ROW_HEIGHT), Math.max(0, snapshot.events.length - 1)) : 0;
  const start = virtual ? Math.max(0, first - OVERSCAN) : 0;
  const end = virtual ? Math.min(snapshot.events.length, first + WINDOW_SIZE + OVERSCAN) : snapshot.events.length;
  const move = (direction: number) => {
    const node = viewport.current;
    if (!node) return;
    node.scrollTop = Math.max(0, Math.min((snapshot.events.length - 1) * ROW_HEIGHT, node.scrollTop + direction * ROW_HEIGHT * WINDOW_SIZE));
    setOffset(node.scrollTop);
  };
  return <>
    <p className="text-muted-foreground">Safe event summaries only. Message bodies, sensitive arguments and raw errors are not retained here.</p>
    {snapshot.dropped > 0 ? <p role="status">History truncated: {snapshot.dropped} oldest {snapshot.dropped === 1 ? 'entry dropped' : 'entries dropped'} to keep the current run within 1,000 entries and 524,288 bytes.</p> : null}
    {snapshot.events.length === 0 ? <p>No events reported for an accepted inspected run.</p> : <>
      {virtual ? <div className="my-s2 flex flex-wrap items-center gap-s2">
        <Button variant="secondary" onClick={() => move(-1)} disabled={first === 0}>Earlier events</Button>
        <Button variant="secondary" onClick={() => move(1)} disabled={first + 2 >= snapshot.events.length}>Later events</Button>
        <p>Window {start + 1}–{end} of {snapshot.events.length} retained entries. Scroll or use the event buttons.</p>
      </div> : null}
      <div ref={viewport} tabIndex={0} role="region" aria-label="Current run events" className="overflow-auto rounded-control border border-border px-s2 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring" style={virtual ? { height: 336 } : { maxHeight: 480 }} onScroll={event => setOffset(event.currentTarget.scrollTop)}>
        <ol aria-label="Retained run event summaries" className="m-0 list-none p-0" style={virtual ? { height: snapshot.events.length * ROW_HEIGHT, position: 'relative' } : undefined}>
          {snapshot.events.slice(start, end).map((event, at) => <EventRow key={`${snapshot.dropped + start + at}`} event={event} index={start + at} total={snapshot.events.length} virtual={virtual} />)}
        </ol>
      </div>
    </>}
  </>;
}

/** Read-only projection; it acquires no transport, approval callback, settings or context selection. */
export function RunInspector({ snapshot, label = 'Current run inspector' }: RunInspectorProps) {
  return <section aria-label={label} className="min-h-0 flex-1 overflow-auto px-s3 py-s3 text-[14px] leading-relaxed">
    <h3 className="mb-s2 font-ui-heading text-[17px] font-semibold">Current run</h3>
    <Tabs key={snapshot.revision} defaultValue="overview">
      <TabsList aria-label="Run inspector sections" className="flex flex-wrap">
        <TabsTrigger value="overview">Overview</TabsTrigger><TabsTrigger value="context">Context</TabsTrigger><TabsTrigger value="prompt">Prompt plan</TabsTrigger><TabsTrigger value="events">Events</TabsTrigger>
      </TabsList>
      <TabsContent value="overview"><Overview snapshot={snapshot} /></TabsContent>
      <TabsContent value="context"><Context facts={snapshot.facts} /></TabsContent>
      <TabsContent value="prompt"><PromptPlan facts={snapshot.facts} /></TabsContent>
      <TabsContent value="events"><Events snapshot={snapshot} /></TabsContent>
    </Tabs>
  </section>;
}
