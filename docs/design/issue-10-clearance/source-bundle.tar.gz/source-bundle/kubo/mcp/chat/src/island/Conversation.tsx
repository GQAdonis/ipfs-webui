import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react';
import { Badge, Button, Notice, interruptExpired, type Tone, type UiTheme } from '@gqadonis/ipfs-mcp-ui';
import { X } from 'lucide-react';
import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, useSidebar } from '../ui/sidebar';
import { BackendEmpty } from './BackendEmpty';
import { Composer } from './Composer';
import { RunNotice, noticeFor } from './RunNotice';
import type { ChatController } from './session';
import type { ReviewSurface } from '../agui/reviewed';
import { buildTimeline } from './timeline';
import { Transcript } from './Transcript';
import { RunInspector } from './RunInspector';

// One conversation: the sidebar with its header, transcript and composer. The session is created once
// per mount; the island remounts this component (by key) when the endpoint changes, so a thread never
// continues against a different server.

export type Readiness =
  | { readonly state: 'ready' }
  | { readonly state: 'no-endpoint'; readonly reason: string }
  | { readonly state: 'no-token' }
  | { readonly state: 'resolving' | 'signing-out' | 'session-expired' };

export interface ConversationProps {
  readonly controller: ChatController;
  readonly readiness: Readiness;
  readonly theme: UiTheme;
  readonly showComposer?: boolean;
  /** The clock, epoch milliseconds. Defaults to Date.now; a test seam the custom element never sets. */
  readonly now?: () => number;
}

/** The host clock as an ISO string, advanced exactly when the next interrupt expiry passes. */
function useNowIso(expiries: readonly string[], clock: () => number): string {
  const [now, setNow] = useState(clock);
  const next = useMemo(() => {
    const times = expiries.map((e) => Date.parse(e)).filter((t) => Number.isFinite(t) && t > now);
    return times.length > 0 ? Math.min(...times) : undefined;
  }, [expiries, now]);
  useEffect(() => {
    if (next === undefined) return;
    const timer = setTimeout(() => setNow(clock()), Math.max(0, next - clock()) + 25);
    return () => clearTimeout(timer);
  }, [next, clock]);
  return new Date(now).toISOString();
}

const EMPTY: Record<Readiness['state'], { title: string; body: string }> = {
  ready: {
    title: 'Ask about your node',
    body: 'Reads run at once. A change waits for your approval in this panel. A removal waits for the system prompt, where you can also deny it.',
  },
  'no-endpoint': {
    title: 'Chat is not configured',
    body: 'The host page sets the ipfs mcp address. Until it does, this panel sends nothing.',
  },
  'no-token': {
    title: 'Chat has no token',
    body: 'The host page supplies the token for the ui principal. Until it does, this panel sends nothing.',
  },
  resolving: { title: 'Connecting', body: 'The host is checking the current connection. Your message has not been sent.' },
  'signing-out': { title: 'Signing out', body: 'The current local connection has been retired and its chat cleared. Sign-out navigation is pending.' },
  'session-expired': { title: 'Sign in again', body: 'The host reported that this sign-in has ended. Sign in again before asking the agent.' },
};
let surfaceCounter = 0;

export function Conversation({ controller: session, readiness, theme, now = Date.now, showComposer = true }: ConversationProps) {
  const [surface] = useState<ReviewSurface>(() => ({ kind: 'chat', instance: `chat_${globalThis.crypto?.randomUUID?.().replaceAll('-', '_') ?? `${Date.now()}_${surfaceCounter++}`}` }));
  const { chat, running, observing, error, decisionActions, intent, intentError, runInspector, runFactsEnabled } = useSyncExternalStore(session.subscribe, session.getSnapshot);
  const [inspecting, setInspecting] = useState(false);
  const { open, setOpen } = useSidebar();
  const panel = useRef<HTMLElement>(null);
  useEffect(() => { if (!runFactsEnabled) setInspecting(false); }, [runFactsEnabled]);

  // Opening moves focus into the panel (the message box, or the title when sending is blocked), so a
  // keyboard user lands where they can act. A composed host owns focus when it places the editor. Closing returns focus to the host's opener; the element does that.
  useEffect(() => {
    if (!open || !showComposer) return;
    const target = panel.current?.querySelector<HTMLElement>('textarea:not([disabled])') ?? panel.current?.querySelector<HTMLElement>('h2');
    target?.focus({ preventScroll: true });
  }, [open, showComposer]);

  // The host owns lifetime. Moving/unmounting a pane only removes this view's subscriptions.

  const items = useMemo(() => buildTimeline(chat), [chat]);
  const expiries = useMemo(
    () => chat.interrupts.filter((i) => i.resolution === undefined && i.interrupt.expiresAt).map((i) => i.interrupt.expiresAt as string),
    [chat.interrupts],
  );
  const notice = noticeFor(error, chat.run);
  // The node is mounted with no model backend: the panel is an empty state with a way to Settings.
  const noBackend = error?.kind === 'backend_not_configured';
  // The retry hold of a 503 ends at an instant, like an interrupt's expiry, so the clock stops there too.
  const holdUntil = error?.retryNotBefore;
  const ticks = useMemo(() => (holdUntil === undefined ? expiries : [...expiries, new Date(holdUntil).toISOString()]), [expiries, holdUntil]);
  const nowIso = useNowIso(ticks, now);
  const nowMs = Date.parse(nowIso);
  const held = holdUntil !== undefined && nowMs < holdUntil;
  const waiting = chat.interrupts.some((i) => i.resolution === undefined && !decisionActions[i.interrupt.metadata['ipfs-mcp'].confirmation_id] && !interruptExpired(i.interrupt, nowIso));

  const blockedReason =
    intent === 'ask' && readiness.state === 'no-endpoint'
      ? 'Not configured.'
      : intent === 'ask' && readiness.state === 'no-token'
        ? 'No token.'
        : intent === 'ask' && readiness.state === 'signing-out'
          ? 'Signing out.'
          : intent === 'ask' && readiness.state === 'resolving'
            ? 'Checking the connection.'
            : intent === 'ask' && readiness.state === 'session-expired'
              ? 'Sign in again.'
        : intent === 'ask' && waiting
          ? 'Answer the approval above first.'
          : intent === 'ask' && held
            ? 'The node asked for a short wait.'
            : undefined;

  const status: { word: string; tone: Tone } =
    readiness.state === 'signing-out'
      ? { word: 'Signing out', tone: 'neutral' }
      : readiness.state === 'resolving'
        ? { word: 'Connecting', tone: 'neutral' }
        : readiness.state === 'session-expired'
          ? { word: 'Sign in again', tone: 'warn' }
    : readiness.state === 'no-endpoint'
      ? { word: 'Not configured', tone: 'neutral' }
      : readiness.state === 'no-token'
        ? { word: 'Needs token', tone: 'warn' }
        : observing.length > 0
          ? { word: 'Waiting for system prompt', tone: 'warn' }
          : running
          ? { word: 'Running', tone: 'info' }
          : waiting
            ? { word: 'Waiting for approval', tone: 'warn' }
            : noBackend
              ? { word: 'No backend', tone: 'warn' }
              : notice
                ? { word: notice.status, tone: notice.tone }
                : { word: 'Ready', tone: 'neutral' };

  const empty = EMPTY[readiness.state];
  const answer: import('./InterruptItem').InterruptItemProps['onAnswer'] = (interruptId, decision, review) => session.answer(interruptId, decision, review);
  const freshProposal: NonNullable<import('./InterruptItem').InterruptItemProps['onFreshProposal']> = async (intent) => {
    const result = await session.requestFreshProposal(intent);
    if (!result.ok) throw new Error('The fresh proposal request was not submitted.');
  };
  // The watch of a system prompt stops when the stream drops or the person stops the run; the
  // confirmation stays pending until it expires, so offer to watch again while an error is showing.
  const watchAgain = !running && error !== undefined ? (interruptId: string) => void session.observe(interruptId) : undefined;

  return (
    <Sidebar label="Agent chat" ref={panel}>
      <SidebarHeader>
        <div className="flex items-center justify-between gap-s2">
          <h2 tabIndex={-1} className="font-ui-heading text-[17px] leading-[1.3] font-semibold">
            Agent chat
          </h2>
          <Button variant="secondary" onClick={() => setOpen(false)}>
            <X size={16} strokeWidth={1.5} aria-hidden="true" />
            Close
          </Button>
        </div>
        {/* Status and the thread action share a row, so the title row stays short at 320px. */}
        <div className="flex flex-wrap items-center justify-between gap-s2">
          <Badge tone={status.tone}>{status.word}</Badge>
          {runFactsEnabled ? <Button variant="secondary" aria-pressed={inspecting} onClick={() => setInspecting(value => !value)}>{inspecting ? 'Show conversation' : 'Inspect run'}</Button> : null}
          <Button variant="secondary" onClick={() => session.reset()} disabled={items.length === 0 && !running}>
            New chat
          </Button>
        </div>
      </SidebarHeader>

      <SidebarContent>
        {inspecting && runFactsEnabled ? <RunInspector snapshot={runInspector} /> : <>
          {items.length === 0 && noBackend ? null : items.length === 0 ? (
            <div className="flex flex-col gap-s2 px-s3 py-s3">
              <h3 className="font-ui-heading text-[17px] leading-[1.3] font-semibold">{empty.title}</h3>
              <p className="max-w-[66ch] text-muted-foreground">
                {readiness.state === 'no-endpoint' ? `${empty.body} ${readiness.reason}` : empty.body}
              </p>
            </div>
          ) : (
            <Transcript controller={session} theme={theme} nowIso={nowIso} onAnswer={answer} onWatchAgain={watchAgain} surface={surface} onFreshProposal={freshProposal} />
          )}
          {noBackend ? <BackendEmpty retryText={error?.retryText} onRetry={() => void session.retry()} onNavigate={() => setOpen(false)} /> : null}
          {notice ? <RunNotice model={notice} nowMs={nowMs} onRetry={() => void session.retry()} /> : null}
          {intentError ? <Notice tone="warn" label="Request kept">{intentError}</Notice> : null}
        </>}
      </SidebarContent>

      {showComposer ? <SidebarFooter>
        <Composer controller={session} blockedReason={blockedReason} />
      </SidebarFooter> : null}
    </Sidebar>
  );
}
