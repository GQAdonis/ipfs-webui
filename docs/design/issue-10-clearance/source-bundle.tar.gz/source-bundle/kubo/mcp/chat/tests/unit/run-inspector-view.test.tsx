import { act, fireEvent, render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it } from 'vitest';
import { UiScope, type InspectorEvent, type RunFacts } from '@gqadonis/ipfs-mcp-ui';
import { RunInspector } from '../../src/island/RunInspector';
import { Conversation } from '../../src/island/Conversation';
import { BackendEmpty } from '../../src/island/BackendEmpty';
import type { RunInspectorSnapshot } from '../../src/island/run-inspector';
import { createChatController } from '../../src/island/session';
import { SidebarProvider } from '../../src/ui/sidebar';

const snapshot = (facts?: RunFacts, extra: Partial<RunInspectorSnapshot> = {}): RunInspectorSnapshot => ({ revision: 1, phase: 'finished', threadId: 'thread_fixture', runId: 'run_fixture', events: [], bytes: 2, dropped: 0, ...(facts && { facts }), ...extra });
const inspect = (state: RunInspectorSnapshot) => render(<UiScope><RunInspector snapshot={state} /></UiScope>);

describe('read-only current run inspector presentation', () => {
  it('keeps four named tabs with absent facts and manual keyboard activation', async () => {
    const user = userEvent.setup(); inspect(snapshot());
    expect(screen.getByRole('heading', { name: 'Current run', level: 3 })).toBeInTheDocument();
    const list = screen.getByRole('tablist', { name: 'Run inspector sections' });
    expect(within(list).getAllByRole('tab')).toHaveLength(4);
    const overview = screen.getByRole('tab', { name: 'Overview' }), context = screen.getByRole('tab', { name: 'Context' });
    expect(overview).toHaveAttribute('aria-selected', 'true');
    expect(screen.getAllByText('Not reported by this server').length).toBeGreaterThan(0);
    overview.focus(); await user.keyboard('{ArrowRight}');
    expect(context).toHaveFocus(); expect(overview).toHaveAttribute('aria-selected', 'true');
    await user.keyboard('{Enter}');
    expect(context).toHaveAttribute('aria-selected', 'true');
    expect(screen.getByText('Not reported by this server')).toBeInTheDocument();
    expect(screen.queryByText('Run state')).not.toBeInTheDocument();
    await user.click(screen.getByRole('tab', { name: 'Prompt plan' }));
    expect(screen.getByRole('heading', { name: 'Offered tools', level: 4 })).toBeInTheDocument();
    expect(screen.getByText(/No prompt text, inferred token budget/)).toBeInTheDocument();
    await user.click(screen.getByRole('tab', { name: 'Events' }));
    expect(screen.getByText('No events reported for an accepted inspected run.')).toBeInTheDocument();
  });

  it('distinguishes explicit empty tools/context and memory none from absent reports', async () => {
    const user = userEvent.setup();
    inspect(snapshot({ offered_tools: [], catalog_size: 72, tool_scope: 'kubo_contract', context_snapshot: [], memory: { scope: 'none' }, egress: { acknowledged_hosts: [] }, provenance: { offered_tools: 'effective_policy_offer', catalog_size: 'loaded_contract', context_snapshot: 'accepted_turn', memory: 'effective_run_snapshot', egress: 'effective_run_snapshot' } }));
    expect(screen.getAllByText('None reported for this run')).toHaveLength(2);
    await user.click(screen.getByRole('tab', { name: 'Context' }));
    expect(screen.getByText('No references in the reported accepted snapshot.')).toBeInTheDocument();
    await user.click(screen.getByRole('tab', { name: 'Prompt plan' }));
    expect(screen.getByText('No tools offered in the reported snapshot.')).toBeInTheDocument();
    expect(screen.getByText('72')).toBeInTheDocument();
    expect(screen.getByText('0')).toBeInTheDocument();
    expect(screen.getByText(/catalog total is not the number available/)).toBeInTheDocument();
  });

  it('renders only reported read-only context text without navigation, resolution or attachments', async () => {
    const user = userEvent.setup();
    inspect(snapshot({ context_snapshot: [{ id: 'page_current', provenance: 'page', route: '/files', path: '/node-only', path_kind: 'mfs' }], provenance: { context_snapshot: 'accepted_turn' } }));
    await user.click(screen.getByRole('tab', { name: 'Context' }));
    expect(screen.getByText('/files')).toBeInTheDocument();
    expect(screen.getByText('/node-only')).toBeInTheDocument();
    expect(screen.getByText('MFS path')).toBeInTheDocument();
    expect(screen.queryByRole('link')).not.toBeInTheDocument();
    expect(screen.queryByRole('textbox')).not.toBeInTheDocument();
    expect(screen.queryByRole('button')).not.toBeInTheDocument();
  });

  it('shows validated UAR facts without inventing model/tool/prompt/memory details', async () => {
    const user = userEvent.setup();
    inspect(snapshot({ backend: { kind: 'uar' }, provenance: { backend: 'effective_run_snapshot' } }));
    expect(screen.getByText('uar')).toBeInTheDocument();
    expect(screen.getAllByText('Not reported by this server').length).toBeGreaterThan(0);
    await user.click(screen.getByRole('tab', { name: 'Prompt plan' }));
    expect(screen.getByText(/UAR tool, prompt and memory facts require a validated backend report/)).toBeInTheDocument();
    expect(screen.queryByText('pin_add')).not.toBeInTheDocument();
    expect(screen.queryByText(/\d+%/)).not.toBeInTheDocument();
  });

  it('virtualizes over200 rows, exposes a named scroll region/range and discloses dropped history', async () => {
    const user = userEvent.setup();
    const events: InspectorEvent[] = Array.from({ length: 1000 }, (_, index) => ({ type: 'tool_call', tool: 'pin_ls', label: `Safe summary ${index}` }));
    const { rerender } = inspect(snapshot(undefined, { events, dropped: 35, bytes: 100000 }));
    await user.click(screen.getByRole('tab', { name: 'Events' }));
    expect(screen.getByText(/35 oldest entries dropped/)).toHaveAttribute('role', 'status');
    const list = screen.getByRole('list', { name: 'Retained run event summaries' });
    expect(within(list).getAllByRole('listitem').length).toBeLessThan(30);
    expect(within(list).getAllByRole('listitem')[0]).toHaveAttribute('aria-setsize', '1000');
    const region = screen.getByRole('region', { name: 'Current run events' });
    expect(region).toHaveAttribute('tabindex', '0');
    fireEvent.scroll(region, { target: { scrollTop: 500 * 168 } });
    expect(screen.queryByText('Safe summary 0')).not.toBeInTheDocument();
    expect(screen.getByText('Safe summary 500')).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Later events' }));
    expect(region.scrollTop).toBeGreaterThan(500 * 168);
    rerender(<UiScope><RunInspector snapshot={snapshot(undefined, { revision: 2, events: [{ type: 'run_started', label: 'New run accepted' }] })} /></UiScope>);
    expect(screen.getByRole('tab', { name: 'Overview' })).toHaveAttribute('aria-selected', 'true');
    await user.click(screen.getByRole('tab', { name: 'Events' }));
    expect(screen.getByText('New run accepted')).toBeInTheDocument();
    expect(screen.queryByText(/oldest entries dropped/)).not.toBeInTheDocument();
  });

  it.each(['light', 'dark'] as const)('feature-off removes inspector controls/panel synchronously while retaining the conversation and editor in %s', async theme => {
    const user = userEvent.setup();
    const controller = createChatController({ connection: { generation: 'fixture', client: null } });
    controller.setDraft('Keep my draft');
    render(<UiScope theme={theme}><SidebarProvider open onOpenChange={() => {}}><Conversation controller={controller} readiness={{ state: 'no-token' }} theme={theme} /></SidebarProvider></UiScope>);
    expect(screen.getByRole('heading', { name: 'Agent chat', level: 2 })).toBeInTheDocument();
    expect(screen.getAllByRole('heading').map(heading => heading.tagName)).toEqual(['H2', 'H3']);
    await user.click(screen.getByRole('button', { name: 'Inspect run' }));
    expect(screen.getByRole('region', { name: 'Current run inspector' })).toBeInTheDocument();
    act(() => controller.setRunFactsEnabled(false));
    expect(screen.queryByRole('region', { name: 'Current run inspector' })).not.toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Inspect run' })).not.toBeInTheDocument();
    expect(controller.getSnapshot().draft).toBe('Keep my draft');
    expect(screen.getByRole('textbox', { name: 'Message to the agent' })).toHaveValue('Keep my draft');
    act(() => controller.setRunFactsEnabled(true));
    expect(screen.getByRole('button', { name: 'Inspect run' })).toHaveAttribute('aria-pressed', 'false');
    controller.dispose();
  });

  it('keeps the backend setup state at the conversation child heading level', () => {
    render(<UiScope><BackendEmpty retryText={undefined} onRetry={() => {}} onNavigate={() => {}} /></UiScope>);
    expect(screen.getByRole('heading', { name: 'Choose a backend to start', level: 3 })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Choose a backend' })).toHaveAttribute('href', '#/settings/agent');
  });

  it('distinguishes simultaneous current and supplemental inspectors while retaining bounded event access', async () => {
    const user = userEvent.setup();
    const events: InspectorEvent[] = Array.from({ length: 1000 }, (_, index) => ({ type: 'tool_call', tool: 'pin_ls', label: `Supplemental summary ${index}` }));
    render(<UiScope><RunInspector snapshot={snapshot()} /><RunInspector label="Supplemental bounded event inspector" snapshot={snapshot(undefined, { events })} /></UiScope>);
    const current = screen.getByRole('region', { name: 'Current run inspector' });
    const supplemental = screen.getByRole('region', { name: 'Supplemental bounded event inspector' });
    await user.click(within(supplemental).getByRole('tab', { name: 'Events' }));
    const rows = within(supplemental).getAllByRole('listitem');
    expect(rows.length).toBeGreaterThan(0);
    expect(rows.length).toBeLessThan(30);
    expect(rows[0]).toHaveAttribute('aria-setsize', '1000');
    expect(within(current).getByRole('tab', { name: 'Overview' })).toHaveAttribute('aria-selected', 'true');
  });
});
