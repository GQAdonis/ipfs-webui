import { z } from 'zod';
import { ApprovalPanel, type ApprovalHandlers } from '../approval/ApprovalPanel';
import type { ApprovalModel } from '../approval/model';
import { AguiInterruptSchema, type AguiInterrupt } from '../contract/generated/agui';
import { approvalCardFacts } from '../approval/card-facts';
import { legacyHostCapabilities } from '../approval/presentation';
import { legacyApprovalPhase } from '../approval/decision';
import { compareInstants } from '../approval/instant';
import { UiScope } from '../scope/UiScope';

export const ApprovalCardDataSchema = z.strictObject({
  /** The AG-UI interrupt exactly as RUN_FINISHED carries it. */
  interrupt: AguiInterruptSchema,
  /** The user's answer in this chat, once given. */
  resolution: z.enum(['approved', 'denied', 'expired']).optional(),
  /** Set by the host from its clock when expiresAt has passed. The card never reads the clock. */
  expired: z.boolean().optional(),
});
export type ApprovalCardData = z.infer<typeof ApprovalCardDataSchema>;

/** Rich models come from the authenticated mapping adapter; callbacks cannot add capability. */
export interface ApprovalCardModelData { readonly model: ApprovalModel }
export type ApprovalCardProps = (ApprovalCardData | ApprovalCardModelData) & ApprovalHandlers & {
  /** Focus Deny for an explicitly opened decision; transcript cards otherwise preserve reader focus. */
  focusSafeAction?: boolean;
};

/**
 * Pure: turn an interrupt and what is known about it into the model the panel renders. The server's
 * message is shown as sent; for a native-prompt call it already says to confirm in the system prompt.
 * A local native-prompt acknowledgement cannot report either approval or operation success.
 */
export function approvalModelFromInterrupt(data: ApprovalCardData): ApprovalModel {
  const meta = data.interrupt.metadata['ipfs-mcp'];
  const native = meta.requires_native_prompt || (meta.class === 'destructive' && !meta.confirmation_id.startsWith('cf_uar_'));
  const phase = legacyApprovalPhase(data.expired ? 'expired' : 'pending', native, data.resolution);
  return {
    ...approvalCardFacts({ tool: meta.tool, summary: data.interrupt.message, class: meta.class, targets: [], provenance: 'agui_interrupt', destination: meta.destination, effectDigest: meta.effect_digest }),
    confirmationId: meta.confirmation_id,
    tool: meta.tool,
    class: meta.class,
    summary: data.interrupt.message,
    targets: [],
    ...(data.interrupt.expiresAt && { expiresAt: data.interrupt.expiresAt }),
    resolvers: native ? [] : ['agui-interrupt'],
    phase,
    requiresNativePrompt: native,
  };
}

/** True when the interrupt's expiresAt is at or before `nowIso`. Pass the host clock in. */
export function interruptExpired(interrupt: AguiInterrupt, nowIso: string): boolean {
  if (!interrupt.expiresAt) return false;
  const ordering = compareInstants(interrupt.expiresAt, nowIso);
  return ordering !== undefined && ordering <= 0;
}

/**
 * The interrupt card of the agent chat: pending, approved, denied, expired, or waiting for the
 * system prompt. It offers Approve only when this chat can answer; when the native prompt decides,
 * it says so and offers no approve control.
 */
export function ApprovalCard({ onApprove, onDeny, onAskAgain, onReviewAgain, onCheckNow, onViewReceipt, originalOperation, focusSafeAction, ...data }: ApprovalCardProps) {
  const model = 'model' in data ? data.model : legacyHostCapabilities(approvalModelFromInterrupt(data), { approve: !!onApprove, deny: !!onDeny });
  return (
    <UiScope>
      <ApprovalPanel
        model={model}
        onApprove={onApprove}
        onDeny={onDeny}
        onAskAgain={onAskAgain}
        onReviewAgain={onReviewAgain}
        onCheckNow={onCheckNow}
        onViewReceipt={onViewReceipt}
        originalOperation={originalOperation}
        {...(focusSafeAction !== undefined && { focusSafeAction })}
        variant="group"
        headingLevel={3}
      />
    </UiScope>
  );
}
