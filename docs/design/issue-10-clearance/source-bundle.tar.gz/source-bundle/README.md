# Issue #10 scoped source handoff

This directory preserves 18 exact final source/test/document files: seven original WebUI scope files, four measured WebUI corrections, five Kubo components and two Kubo regression files. The manifest records each SHA-256 and retained freeze/receipt identities. Every copied byte matched its recorded final freeze before this package was written.

This is a non-standalone local handoff, not a patch applicable to upstream or a completed PR. The current WebUI checkout HEAD is ac12af52cf461890d6bc2d4593b1ff4a77c029b9; its boundary runner and boundary tree are untracked. The Kubo HEAD is a3bd2fbbe3114e217730b514ef82732a369510ea; RunInspector and its regression file are untracked and the other measured files are modified. Complete snapshots necessarily include migration context already present before issue #10.

Applying these files requires the matching existing frontend migration and its actual boundary runner, process/evidence/export helpers, family fixtures, production shell/chat/inspector views, shared contracts, dependency manifests/locks and generated artifacts. None is invented or relaxed by this handoff. Do not stage this whole directory as an application patch against origin, or infer runnable completeness from its manifest.

For later code delivery, first land the separately owned migration prerequisites in reviewable commits, then port this bounded correction against that frozen baseline and run the normal export/assembly and WU/SU checks. Alternatively retain this scoped handoff alongside the existing local migrated tree for operator review. This package alone does not establish remote publication, merge or installation. No commit/push/PR or archive was performed.
