import AutoSizer from '../../components/auto-sizer/AutoSizer.js'
import React, { useCallback, useMemo, useState } from 'react'
import classNames from 'classnames'
import ms from 'milliseconds'
import { connect } from '../../lib/react-store.js'
import { withTranslation } from 'react-i18next'
import { Table, Column, SortDirection } from 'react-virtualized'
import CountryFlag from '../../components/country-flag/CountryFlag.js'
import { CopyToClipboard } from '../../components/copy-to-clipboard/CopyToClipboard.js'
import Cid from '../../components/cid/Cid.js'
import { sortByProperty } from '../../lib/sort.js'
import { GlobeIcon, NetworkIcon } from '../../promethity/icons.js'

import './PeersTable.css'

const flagRenderer = (flagCode, isPrivate) => {
  // Check if the OS is Windows to render the flags as SVGs
  // Windows doesn't render the flags as emojis  ¯\_(ツ)_/¯
  const isWindows = window.navigator.appVersion.indexOf('Win') !== -1
  return (
      <span className='f4 pr2'>
        {isPrivate ? <NetworkIcon size={18} /> : flagCode ? <CountryFlag code={flagCode} svg={isWindows} /> : <GlobeIcon size={18} />}
      </span>
  )
}

const locationCellRenderer = (t) => ({ rowData }) => {
  const ref = React.createRef()
  const location = rowData.isPrivate
    ? t('localNetwork')
    : rowData.location
      ? rowData.isNearby
        ? <span>{rowData.location} <span className='charcoal-muted'>({t('nearby')})</span></span>
        : rowData.location
      : <span className='charcoal-muted fw4'>{t('app:terms.unknown')}</span>
  const value = rowData.location || t('app:terms.unknown')
  return (
      <CopyToClipboard text={value} onCopy={() => copyFeedback(ref, t)}>
        <span title={value} className='copyable' ref={ref}>
          { flagRenderer(rowData.flagCode, rowData.isPrivate) }
          { location }
        </span>
      </CopyToClipboard>
  )
}

const latencyCellRenderer = ({ cellData }) => {
  const style = { width: '60px' }
  const latency = `${cellData}ms`
  if (cellData == null) return (<span className='dib o-40 no-select' style={style}>-</span>)
  return (<span className='dib no-select'>{latency}</span>)
}

const peerIdCellRenderer = (t) => ({ cellData: peerId }) => {
  const ref = React.createRef()
  const p2pMultiaddr = `/p2p/${peerId}`
  return (
      <CopyToClipboard text={p2pMultiaddr} onCopy={() => copyFeedback(ref, t)}>
        <Cid value={peerId} identicon ref={ref} className='copyable' />
      </CopyToClipboard>
  )
}

const protocolsCellRenderer = (t) => ({ rowData }) => {
  const ref = React.createRef()
  const { protocols } = rowData
  const title = protocols.split(', ').join('\n')
  return (
      <CopyToClipboard text={protocols} onCopy={() => copyFeedback(ref, t)}>
        <span
          ref={ref}
          className='copyable'
          title={title}>
          { protocols.replaceAll('[unnamed]', '(unnamed)') }
        </span>
      </CopyToClipboard>
  )
}

const agentVersionCellRenderer = (t) => ({ rowData }) => {
  const ref = React.createRef()
  const { agentVersion } = rowData
  if (!agentVersion) return (<span className='dib o-40 no-select'>-</span>)
  return (
      <CopyToClipboard text={agentVersion} onCopy={() => copyFeedback(ref, t)}>
        <span
          ref={ref}
          className='copyable'
          title={agentVersion}>
          { agentVersion }
        </span>
      </CopyToClipboard>
  )
}

const connectionCellRenderer = (t) => ({ rowData }) => {
  const ref = React.createRef()
  const { address, direction, peerId } = rowData
  const p2pMultiaddr = `${address}/p2p/${peerId}`
  const title = direction != null
    ? `${address}\n(${renderDirection(direction, t)})`
    : address

  return (
      <CopyToClipboard text={p2pMultiaddr} onCopy={() => copyFeedback(ref, t)}>
        <abbr
          ref={ref}
          className='copyable'
          title={title}>
          {rowData.connection}
        </abbr>
      </CopyToClipboard>
  )
}

const rowClassRenderer = ({ index }, peers = [], selectedPeers) => {
  const shouldAddHoverEffect = selectedPeers?.peerIds?.includes(peers[index]?.peerId)

  return classNames('peersTableItem', index === -1 && 'bg-near-white', shouldAddHoverEffect && 'bg-light-gray')
}

export const FilterInput = ({ filter, setFilter, t, filteredCount }) => {
  const handleKeyDown = (e) => {
    if (e.key === 'Escape') {
      setFilter('')
    }
  }

  // N3: a labelled field with its count beside it in normal flow (the count
  // used to be an unlabelled absolute-positioned number with no positioned
  // ancestor). The label is visible, so it does not vanish once something is
  // typed. The count is plain text the field is described by: a live region
  // would announce on every peer that connects or leaves.
  return (
    <div className='peers-filter relative flex flex-wrap items-center pa2'>
      <label htmlFor='peers-filter-input' className='peers-filter-label f6 charcoal-muted mr3'>{t('filterLabel')}</label>
      <input
        id='peers-filter-input'
        aria-describedby='peers-filter-count'
        className='input-reset ba pa2 db flex-auto'
        type='text'
        placeholder={t('filterPlaceholder')}
        value={filter}
        onChange={(e) => setFilter(e.target.value)}
        onKeyDown={handleKeyDown}
      />
      <span id='peers-filter-count' className='peers-filter-count f6 charcoal-muted ml3 nowrap' data-testid='peers-count'>
        {t('peerCount', { count: filteredCount })}
      </span>
    </div>
  )
}

export const PeersTable = ({ className, t, peerLocationsForSwarm, selectedPeers }) => {
  const tableHeight = 400
  const peers = useMemo(() => peerLocationsForSwarm || [], [peerLocationsForSwarm])
  const [sortBy, setSortBy] = useState('latency')
  const [sortDirection, setSortDirection] = useState(SortDirection.ASC)
  const [filter, setFilter] = useState('')

  const sort = useCallback(({ sortBy, sortDirection }) => {
    setSortBy(sortBy)
    setSortDirection(sortDirection)
  }, [])
  const filterCb = useCallback((value) => {
    setFilter(value)
  }, [])

  const filteredPeerList = useMemo(() => {
    const filterLower = filter.toLowerCase()
    if (filterLower === '') return peers
    const peerFilter = filter.startsWith('/p2p/') ? filter.slice(5) : filter
    return peers.filter(({ location, latency, peerId, connection, protocols, agentVersion }) => {
      if (location != null && location.toLowerCase().includes(filterLower)) {
        return true
      }
      if (latency != null && [latency, `${latency}ms`].some((str) => str.toString().includes(filterLower))) {
        return true
      }
      if (peerId != null && peerId.toString().includes(peerFilter)) {
        return true
      }
      if (connection != null && connection.toLowerCase().includes(filterLower)) {
        return true
      }
      if (protocols != null && protocols.toLowerCase().includes(filterLower)) {
        return true
      }
      if (agentVersion != null && agentVersion.toLowerCase().includes(filterLower)) {
        return true
      }

      return false
    })
  }, [peers, filter])

  const sortedList = useMemo(
    () => filteredPeerList.sort(sortByProperty(sortBy, sortDirection === SortDirection.ASC ? 1 : -1)),
    [filteredPeerList, sortBy, sortDirection]
  )

  return (
    <div className={`bg-white-70 center ${className}`} style={{ height: `${tableHeight}px`, maxWidth: 1764 }}>
        <FilterInput filter={filter} setFilter={filterCb} t={t} filteredCount={sortedList.length} />
        { peers && <div className='peers-table-frame'><div className='peers-table-inner'><AutoSizer disableHeight>
          {({ width }) => (
            <>
              <Table
                className='tl fw4 w-100 f6'
                headerClassName='charcoal-muted fw6 ph2 no-select'
                rowClassName={(rowInfo) => rowClassRenderer(rowInfo, peers, selectedPeers)}
                width={width}
                height={tableHeight}
                headerHeight={32}
                rowHeight={36}
                rowCount={sortedList.length}
                noRowsRenderer={() => <p className='peers-empty ma0 pa3 f6 charcoal-muted'>{filter ? t('noPeersMatch') : t('noPeers')}</p>}
                rowGetter={({ index }) => sortedList[index]}
                sort={sort}
                sortBy={sortBy}
                sortDirection={sortDirection}>
                <Column label={t('app:terms.location')} cellRenderer={locationCellRenderer(t)} dataKey='location' width={350} className='f6 charcoal truncate pl2' />
                <Column label={t('app:terms.latency')} cellRenderer={latencyCellRenderer} dataKey='latency' width={130} className='f6 charcoal pl2' />
                <Column label={t('app:terms.peerId')} cellRenderer={peerIdCellRenderer(t)} dataKey='peerId' width={200} className='charcoal monospace truncate f6 pl2' />
                <Column label={t('app:terms.connection')} cellRenderer={connectionCellRenderer(t)} dataKey='connection' width={200} className='charcoal monospace truncate f7 pl2' />
                <Column label={t('agentVersion')} cellRenderer={agentVersionCellRenderer(t)} dataKey='agentVersion' width={250} className='charcoal monospace truncate f7 pl2' />
                <Column label={t('protocols')} cellRenderer={protocolsCellRenderer(t)} dataKey='protocols' width={420} className='charcoal monospace truncate f7 pl2' />
              </Table>
            </>
          )}
        </AutoSizer></div></div> }
      </div>
  )
}

// API returns integer atm, but that may change in the future
// Current mapping based on https://github.com/libp2p/go-libp2p-core/blob/21efed75194d73e21e16fe3124fb9c4127a85308/network/network.go#L38-39
const renderDirection = (direction, i18n) => {
  if (direction == null) return
  switch (direction) {
    case 1:
      return i18n('connectionDirectionInbound')
    case 2:
      return i18n('connectionDirectionOutbound')
    default:
      return direction
  }
}

// temporarily replaces contents of element with 'copied!'
const copyFeedback = (ref, t) => {
  const tag = ref.current
  const { parentNode } = tag
  const msg = document.createElement('em')
  msg.innerText = t('copyFeedback')
  parentNode.replaceChild(msg, tag)
  setTimeout(() => parentNode.replaceChild(tag, msg), ms.seconds(2))
}

export default connect(
  'selectPeerLocationsForSwarm',
  'selectSelectedPeers',
  withTranslation('peers')(PeersTable)
)
