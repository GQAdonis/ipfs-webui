import React from 'react'
import { useTranslation } from 'react-i18next'
import IconTooltip from '../../components/tooltip/icon-tooltip'
import { InfoIcon } from '../../promethity/icons.js'
import type { SweepProvideStats } from '../../contexts/ProvideStat/types'
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent
} from '../../components/card/card'
import { MetricRow } from '../../components/metric-row/MetricRow'
import { safeNumber } from './format-utils'

interface Props {
  sweep: SweepProvideStats
}

export const Workers: React.FC<Props> = ({ sweep }) => {
  const { t } = useTranslation('diagnostics')

  const max = safeNumber(sweep.workers?.max)
  const active = safeNumber(sweep.workers?.active)
  const activePeriodic = safeNumber(sweep.workers?.active_periodic)
  const activeBurst = safeNumber(sweep.workers?.active_burst)
  const dedicatedPeriodic = safeNumber(sweep.workers?.dedicated_periodic)
  const dedicatedBurst = safeNumber(sweep.workers?.dedicated_burst)
  const queuedPeriodic = safeNumber(sweep.workers?.queued_periodic)
  const queuedBurst = safeNumber(sweep.workers?.queued_burst)
  const connsPerWorker = safeNumber(sweep.workers?.max_provide_conns_per_worker)

  const utilization = max > 0
    ? Math.round((active / max) * 100)
    : 0

  const availableReservedBurst = Math.max(0, dedicatedBurst - activeBurst)
  const availableReservedPeriodic = Math.max(0, dedicatedPeriodic - activePeriodic)
  const availableFreeWorkers = Math.max(0, max - Math.max(dedicatedBurst, activeBurst) - Math.max(dedicatedPeriodic, activePeriodic))
  const availableBurst = availableFreeWorkers + availableReservedBurst
  const availablePeriodic = availableFreeWorkers + availableReservedPeriodic

  const periodicUtil =
    dedicatedPeriodic > 0 ? activePeriodic / availablePeriodic : 0

  const burstUtil =
    dedicatedBurst > 0 ? activeBurst / availableBurst : 0

  const Bar: React.FC<{ value: number }> = ({ value }) => (
    <div className='bg-black-10 br1 overflow-hidden w-100'>
      <div
        className='bg-teal-muted o-60'
        style={{ width: `${Math.min(100, value * 100)}%`, height: 6 }}
      />
    </div>
  )

  return (
    <Card>
      <CardHeader className='flex justify-between items-center'>
        <CardTitle>{t('dhtProvide.workers.title')}</CardTitle>
        <IconTooltip text={t('dhtProvide.workers.tooltip')} position='top'>
          <InfoIcon className='fill-charcoal-muted pointer' size={22} />
        </IconTooltip>
      </CardHeader>
      <CardContent>
        <div className='mb3'>
          <MetricRow
            label={t('dhtProvide.workers.active')}
            value={`${active} / ${max}`}
            highlight={utilization >= 75}
          />
          <div className='mt1'>
            <Bar value={utilization / 100} />
          </div>
        </div>

        <div className='mt3 pt3'>
          <div className='mb3'>
            <MetricRow
              label={t('dhtProvide.workers.periodic')}
              value={`${activePeriodic} active (${dedicatedPeriodic} dedicated, ${availablePeriodic} available)`}
            />
            <div className='mt1'>
              <Bar value={periodicUtil} />
            </div>
          </div>

          <div className='mb3'>
            <MetricRow
              label={t('dhtProvide.workers.burst')}
              value={`${activeBurst} active (${dedicatedBurst} dedicated, ${availableBurst} available)`}
            />
            <div className='mt1'>
              <Bar value={burstUtil} />
            </div>
          </div>

          {(queuedPeriodic > 0 || queuedBurst > 0) && (
            <MetricRow
              label={t('dhtProvide.workers.queued')}
              value={`${queuedPeriodic} / ${queuedBurst}`}
              highlight={queuedPeriodic + queuedBurst > 0}
            />
          )}
        </div>

        <div className='mt3 pt3'>
          <MetricRow
            label={t('dhtProvide.workers.maxConnsPerWorker')}
            value={connsPerWorker.toString()}
          />
        </div>
      </CardContent>
    </Card>
  )
}
