import React from 'react'
import { vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import { App } from './App.js'

vi.mock('./navigation/NavBar.js', () => ({ default: () => <nav aria-label='Navigation' /> }))
vi.mock('./components/notify/Notify.js', () => ({ default: () => null }))
vi.mock('./components/connected/Connected.js', () => ({ default: () => null }))
vi.mock('./components/tour/Tour.js', () => ({ default: () => null }))
vi.mock('./components/tour/TourHelper.js', () => ({ default: () => null }))
vi.mock('./files/explore-form/files-explore-form.tsx', () => ({ default: () => <input aria-label='IPFS path' /> }))
vi.mock('./agent-chat/index.js', () => ({ AgentChatLauncher: () => null, SessionBanner: () => null }))
vi.mock('./webmcp/index.js', () => ({ WebMcpHost: () => null }))

const props = () => ({
  t: key => key, route: () => <h1>Current page</h1>, routeInfo: { url: '/files' },
  doSetupLocalStorage: vi.fn(), doTryInitIpfs: vi.fn(), doUpdateUrl: vi.fn(), doUpdateHash: vi.fn(),
  doFilesWrite: vi.fn(), doFilesNavigateTo: vi.fn(), doDisableTooltip: vi.fn(),
  isOver: false, canDrop: false, showTooltip: false, ipfsReady: true
})

it('starts the existing store actions once and mounts the chosen route', () => {
  const initial = props()
  const view = render(<App {...initial} />)
  expect(screen.getByRole('heading', { name: 'Current page' })).toBeVisible()
  expect(screen.getByRole('navigation')).toBeInTheDocument()
  view.rerender(<App {...initial} />)
  expect(initial.doSetupLocalStorage).toHaveBeenCalledTimes(1)
  expect(initial.doTryInitIpfs).toHaveBeenCalledTimes(1)
})

it('keeps welcome/settings usable while disconnected and waits for IPFS on other routes', () => {
  const initial = { ...props(), ipfsReady: false }
  const view = render(<App {...initial} />)
  expect(screen.queryByRole('heading')).toBeNull()
  view.rerender(<App {...initial} routeInfo={{ url: '/welcome' }} />)
  expect(screen.getByRole('heading')).toBeVisible()
  view.rerender(<App {...initial} routeInfo={{ url: '/settings' }} />)
  expect(screen.getByRole('heading')).toBeVisible()
})

it.each(['/files', '/pins', '/explore/bafy-example', '/peers', '/diagnostics', '/settings/agent'])('keeps the selected %s route inside the application layout', url => {
  const { container } = render(<App {...props()} routeInfo={{ url }} />)
  expect(container.querySelector('[data-workspace-mode="application"]')).toBeInTheDocument()
  expect(screen.getByRole('main')).toHaveAttribute('data-route', url.split('/')[1])
  expect(screen.getByRole('heading', { name: 'Current page' })).toBeVisible()
  // Until S1.3 supplies a real gated host, no empty pane or second input is added.
  expect(container.querySelector('[data-workspace-slot="conversation"]')).toBeNull()
  expect(container.querySelector('[data-workspace-slot="canvas"]')).toBeNull()
  expect(screen.getAllByRole('textbox')).toHaveLength(1)
  expect(container.querySelector('[data-workspace-slot="navigator"]').compareDocumentPosition(screen.getByRole('main')) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy()
  if (url.startsWith('/explore')) {
    expect(container.querySelector('[data-workspace-slot="application"]')).toHaveClass('prom-explore')
  }
})

it('does not remount an active IPFS operation during shell status updates', () => {
  const mounted = vi.fn()
  const disposed = vi.fn()
  function Operation () {
    React.useEffect(() => { mounted(); return disposed }, [])
    return <input aria-label='File operation selection' defaultValue='Selected file' />
  }
  const initial = { ...props(), route: Operation }
  const view = render(<App {...initial} />)
  const operation = screen.getByRole('textbox', { name: 'File operation selection' })
  view.rerender(<App {...initial} canDrop isOver showTooltip />)
  expect(screen.getByRole('textbox', { name: 'File operation selection' })).toBe(operation)
  expect(mounted).toHaveBeenCalledTimes(1)
  expect(disposed).not.toHaveBeenCalled()
  expect(initial.doTryInitIpfs).toHaveBeenCalledTimes(1)
  view.unmount()
  expect(disposed).toHaveBeenCalledTimes(1)
})
