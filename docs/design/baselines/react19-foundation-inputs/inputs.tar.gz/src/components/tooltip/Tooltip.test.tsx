import React from 'react'
import { vi } from 'vitest'
import { render } from '@testing-library/react'
import Tooltip from './Tooltip'

it('preserves and disposes the child React19 ref', () => {
  const cleanup = vi.fn()
  const ref = vi.fn(() => cleanup)
  const view = render(<Tooltip text='Full label'><span ref={ref}>Label</span></Tooltip>)
  expect(ref).toHaveBeenCalledWith(view.getByText('Label'))
  view.unmount()
  expect(cleanup).toHaveBeenCalledTimes(1)
})
