import React from 'react'
import { vi } from 'vitest'
import { render } from '@testing-library/react'
import Tour from './Tour.js'
const { capture } = vi.hoisted(() => ({ capture: vi.fn() }))
vi.mock('react-joyride', () => ({ Joyride: props => { capture(props); return null } }))
it('keeps translated content, dismissal, local skin and disabled-state on the new API', () => {
  const callback = vi.fn()
  render(<Tour run={false} callback={callback} showProgress disableOverlay styles={{ options: { backgroundColor: 'var(--raised)' }, buttonNext: { color: 'var(--text)' } }} steps={[{ target: 'body', content: 'Localized step', disableBeacon: true }]} />)
  const props = capture.mock.lastCall[0]
  expect(props.run).toBe(false)
  expect(props.onEvent).toBe(callback)
  expect(props.options).toMatchObject({ showProgress: true, hideOverlay: true, backgroundColor: 'var(--raised)' })
  expect(props.steps[0]).toMatchObject({ content: 'Localized step', skipBeacon: true })
  expect(props.styles.buttonPrimary).toEqual({ color: 'var(--text)' })
  expect(props).not.toHaveProperty('callback')
})
