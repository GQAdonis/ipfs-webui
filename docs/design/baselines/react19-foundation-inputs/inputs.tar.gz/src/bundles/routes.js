import { createRouteBundle } from 'redux-bundler'
import StatusPage from '../status/LoadableStatusPage.js'
import FilesPage from '../files/LoadableFilesPage.js'
import PinsPage from '../pins/LoadablePinsPage.js'
import PeersPage from '../peers/LoadablePeersPage.js'
import SettingsPage from '../settings/LoadableSettingsPage.js'
import AnalyticsPage from '../settings/AnalyticsPage.js'
import AgentSettingsPage from '../settings/agent/LoadableAgentSettingsPage.js'
import SearchPage from '../search/LoadableSearchPage.js'
import WelcomePage from '../welcome/LoadableWelcomePage.js'
import BlankPage from '../blank/BlankPage.js'
import ExplorePageRenderer from '../explore/explore-page-renderer.jsx'
import DiagnosticsPage from '../diagnostics/loadable-diagnostics-page'

export default createRouteBundle({
  '/explore': ExplorePageRenderer,
  '/explore*': ExplorePageRenderer,
  '/files*': FilesPage,
  '/ipfs*': FilesPage,
  '/ipns*': FilesPage,
  '/pins*': PinsPage,
  '/peers': PeersPage,
  '/search': SearchPage,
  '/settings/analytics': AnalyticsPage,
  '/settings/agent': AgentSettingsPage,
  '/settings*': SettingsPage,
  '/welcome': WelcomePage,
  '/blank': BlankPage,
  '/diagnostics*': DiagnosticsPage,
  '/status*': StatusPage,
  '/': StatusPage,
  '': StatusPage
}, { routeInfoSelector: 'selectHash' })
