import { dirname, join } from 'path'

export function selectedMoveOperations (selectedFiles, source, destination) {
  const operations = selectedFiles.map(file => [file.path, join(dirname(destination), file.name)])
  if (!operations.some(([path]) => path === source)) operations.push([source, destination])
  return operations.filter(([from, to]) => from !== to)
}
