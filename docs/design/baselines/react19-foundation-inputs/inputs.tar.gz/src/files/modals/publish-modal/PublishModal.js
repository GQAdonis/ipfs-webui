import React, { useEffect, useState } from 'react'
import PropTypes from 'prop-types'
import { withTranslation } from 'react-i18next'
import { CopyToClipboard } from '../../../components/copy-to-clipboard/CopyToClipboard.js'
import Button from '../../../components/button/button.tsx'
import { Modal, ModalActions, ModalBody } from '../../../components/modal/modal'
import { PublishIcon as Icon, CopyIcon as GlyphCopy, CheckIcon as GlyphTick } from '../../../promethity/icons.js'
import { connect } from '../../../lib/react-store.js'
import Radio from '../../../components/radio/radio.js'
import { buildShareLink, toIpnsBase36 } from '../../../lib/share-link.js'
import ProgressBar from '../../../components/progress-bar/ProgressBar.js'
import './PublishModal.css'

export const PublishModal = ({ t, tReady, onLeave, onSubmit, file, ipnsKeys, effectiveShareLinkType, localGatewayUrl, publicGateway, publicSubdomainGateway, className = '', doFetchIpnsKeys, doUpdateExpectedPublishTime, expectedPublishTime, ...props }) => {
  const [disabled, setDisabled] = useState(true)
  const [error, setError] = useState(null)
  const [selectedKey, setSelectedKey] = useState({ name: '', id: '' })
  const [link, setLink] = useState('')
  const [start, setStart] = useState(null)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    setDisabled(selectedKey.name === '' || start !== null)
  }, [selectedKey, start])

  useEffect(() => {
    doFetchIpnsKeys()
  }, [doFetchIpnsKeys])

  useEffect(() => {
    if (copied) {
      const timeoutId = setTimeout(() => setCopied(false), 2000)
      return () => clearTimeout(timeoutId)
    }
  }, [copied])

  const changeKey = (key) => {
    setLink('')
    setError(null)
    setSelectedKey(key)
  }

  const publish = async () => {
    try {
      const startTs = new Date().getTime()
      setStart(startTs)
      setError(null)

      await onSubmit(selectedKey.name)
      // Match the Share Link type chosen in Settings; the effective type
      // guarantees buildShareLink returns a link. The name is normalized to a
      // base36 libp2p-key so subdomain and native links are valid.
      const ipnsName = toIpnsBase36(selectedKey.id)
      setLink(buildShareLink({
        type: effectiveShareLinkType,
        namespace: 'ipns',
        pathId: ipnsName,
        subdomainLabel: ipnsName,
        localGatewayUrl,
        publicGateway,
        publicSubdomainGateway
      }))

      // Update the expected time with the new timing.
      const endTs = new Date().getTime()
      doUpdateExpectedPublishTime((endTs - startTs) / 1000)
    } catch (err) {
      // Leave the progress state so the error renders and Publish re-enables for a retry.
      setStart(null)
      setError(err)
    }
  }

  const modalBody = () => {
    if (link) {
      return (
        <div>
          <div className='tl pv3'>{t('publishModal.publishedUnderKey')}
            <div className='f6 mv2 charcoal-muted monospace'>
              <a target='_blank' rel='noopener noreferrer' className='link' href={link}>{selectedKey.name}</a>
            </div>
            <div className='f6 charcoal-muted monospace truncate'>
              <a target='_blank' rel='noopener noreferrer' className='link' href={link}>{selectedKey.id}</a>
            </div>
          </div>
          <p className='charcoal tl center'>{t('publishModal.sharingPrompt')}</p>
          <div className='flex center mb2 relative'>
            <input
              value={link}
              readOnly
              className={'input-reset flex-grow-1 charcoal-muted ba br1 pa2 focus-outline'}
              style={{ color: 'var(--text-muted)', opacity: copied ? 0.6 : 1 }}
              type='text' />

            <div className='absolute h2 pl2 flex items-center' style={{ right: '4px', top: '50%', transform: 'translateY(-50%)', background: 'var(--control)' }} >
              { copied
                ? <>
                  <span className="charcoal-muted strong f5">{t('publishModal.linkCopied')}</span>
                  <GlyphTick className='fill-aqua w2' />
                </>
                : <CopyToClipboard text={link} onCopy={() => setCopied(true)}>
                  <GlyphCopy className='fill-charcoal-muted w2 h2 pointer' />
                </CopyToClipboard>
              }
            </div>
          </div>
        </div>
      )
    }

    if (start) {
      return (
        <div>
          <p className='charcoal tl center'>{t('publishModal.pleaseWait')}</p>
          <ProgressBar bg='bg-teal' style={{ height: '8px' }} time={expectedPublishTime} />
        </div>
      )
    }

    return (
      <div>
        <div className='tl pv3'>{t('publishModal.publishUnderKey')}</div>
        <div className="publishModalKeys">
          { ipnsKeys.map((key) => (
            <button className="flex items-center pa1 hoverable-button" key={key.name} onClick={() => changeKey(key)}>
              <Radio className='pv3 pl3 pr1 flex-none' checked={key.name === selectedKey.name} label={key.name} style={{ pointerEvents: 'none' }} />
            </button>
          ))}
        </div>
        <span className="mb1 tl f7 charcoal-muted">{ t('publishModal.help') }</span>

        { error && <p className='ma0 lh-copy red f5 mw7'>{error.toString()}</p>}
      </div>
    )
  }

  return (
    <Modal {...props} className={className} onCancel={onLeave} >
      <ModalBody Icon={Icon} title={t('publishModal.title')}>
        <div className='tl pv3'>
          {t('publishModal.cidToPublish')}
          <div className='f6 mt1 charcoal-muted monospace'>{file.cid.toString()}</div>
        </div>
        {modalBody()}
      </ModalBody>

      <ModalActions>
        { link
          ? <Button className='ma2 tc ml-auto' onClick={onLeave}>{t('app:actions.done')}</Button>
          : <>
            <Button className='ma2 tc' bg='bg-gray' onClick={onLeave}>{t('app:actions.cancel')}</Button>
            <Button className='ma2 tc' bg='bg-teal' disabled={disabled} onClick={publish}>{t('app:actions.publish')}</Button>
          </>
        }

      </ModalActions>
    </Modal>
  )
}

PublishModal.propTypes = {
  onLeave: PropTypes.func.isRequired,
  onSubmit: PropTypes.func.isRequired,
  t: PropTypes.func.isRequired,
  file: PropTypes.object,
  tReady: PropTypes.bool
}



export default connect(
  'selectIpnsKeys',
  'selectExpectedPublishTime',
  'selectLocalGatewayUrl',
  'selectPublicGateway',
  'selectPublicSubdomainGateway',
  'selectEffectiveShareLinkType',
  'doFetchIpnsKeys',
  'doUpdateExpectedPublishTime',
  withTranslation('files')(PublishModal)
)
