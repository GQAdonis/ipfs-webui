// Exercise the maintained source against its isolated original closure, including the
// preserved upstream codec/path fixtures. F1.9 checks the generated/installed artifact freshness.
import '../../vendor/ipld-explorer-components/src/lib/cid.test.js'
import '../../vendor/ipld-explorer-components/src/lib/normalize-dag-node.test.js'
import '../../vendor/ipld-explorer-components/src/lib/resolve-ipld-path.test.js'
import '../../vendor/ipld-explorer-components/src/components/graph-crumb/graph-crumb.test.js'
